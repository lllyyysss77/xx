# 🚨 严重安全警告

**发现时间**：2026-09-08  
**影响范围**：生产数据库完全暴露

---

## 密码泄露详情

### 泄露位置
1. `backend-new/.env` (已被 Git 追踪并提交过)
2. `README-部署说明.md` 第 36 行
3. `数据库真相报告.md` 第 12 行

### 泄露内容
```
数据库：db.ydkuibtqrcohjcxmvcfm.supabase.co:5432
用户名：postgres
密码：Zo4xia@outlook.com
```

### Git 历史
- Commit: `bc8f5bbce78affd06e2345114d12addf907e90ac`
- Date: 2026-09-05 06:24:52
- Message: "1"
- **此 commit 已将 `.env` 提交到版本库**

---

## 风险评估

### 🔴 极高风险
- ✅ 凭证真实有效（健康检查验证通过）
- ✅ 密码已提交到 Git 版本库（**无法撤回**）
- ✅ 如代码已推送到 GitHub/远程仓库，**密码已永久泄露**
- ✅ 任何拿到代码的人可以：
  - 直连生产数据库
  - 读取所有数据（包括用户手机号、密码哈希）
  - 删除所有表
  - 篡改选举数据

### 受影响数据
根据 `数据库真相报告.md`：
- 5 个内部管理账号（含平台超管）
- 2 个组织（霞皋村、涧口社区）
- 25 张表的完整结构
- 所有历史选举数据（如有）

---

## 立即行动（按顺序执行）

### 1. 轮换密码（最高优先）
```bash
# 登录 Supabase 控制台
# Settings -> Database -> Reset Database Password
# 生成新密码（建议 32 位随机）
```

### 2. 更新本地配置
```bash
# 修改 backend-new/.env
DATABASE_URL=postgresql://postgres:<新密码>@db.ydkuibtqrcohjcxmvcfm.supabase.co:5432/postgres?sslmode=verify-full&sslrootcert=supabase-ca.crt
```

### 3. 清理文档明文
```bash
# 编辑以下文件，删除明文密码，改为占位符
README-部署说明.md
数据库真相报告.md
```

### 4. Git 历史处理
⚠️ **重要**：Git 历史中的密码**无法安全删除**（如已推送到远程）

选项 A（已推送到公开仓库）：
- **假设密码已泄露**
- 必须轮换密码（见步骤 1）
- 不要尝试 `git filter-branch` / `git rebase`（会破坏协作历史）

选项 B（仅本地 Git，未推送）：
```bash
# 从历史删除 .env（会改写所有 commit SHA）
git filter-branch --force --index-filter \
  'git rm --cached --ignore-unmatch backend-new/.env' \
  --prune-empty --tag-name-filter cat -- --all

# 强制推送（危险！）
git push origin --force --all
```

### 5. 验证修复
```bash
# 确认旧密码已失效
psql "postgresql://postgres:Zo4xia%40outlook.com@db.ydkuibtqrcohjcxmvcfm.supabase.co:5432/postgres"
# 应返回: FATAL: password authentication failed

# 确认新密码有效
psql "postgresql://postgres:<新密码>@db.ydkuibtqrcohjcxmvcfm.supabase.co:5432/postgres"
# 应返回: postgres=#
```

---

## 预防措施

### .gitignore 已配置（无需修改）
```
.env
.env.*
!.env.example
```

### .env.example 模板
```bash
# 创建 backend-new/.env.example
DATABASE_URL=postgresql://postgres:<YOUR_PASSWORD>@<YOUR_HOST>:5432/postgres
PORT=3100
JWT_SECRET=<生成随机 32 位字符串>
```

### 自动化检查
```bash
# 安装 git-secrets 防止未来泄露
git secrets --install
git secrets --register-aws
git secrets --add 'password.*=.*'
```

---

## 责任人

- **发现人**：AI Assistant（4层深度扫描）
- **执行人**：<待填写>
- **验证人**：<待填写>
- **完成时间**：<待填写>

---

## 签字确认

- [ ] 已轮换 Supabase 密码
- [ ] 已更新本地 .env
- [ ] 已清理文档明文
- [ ] 已验证旧密码失效
- [ ] 已通知所有相关人员

**签字**：____________  
**日期**：____________
