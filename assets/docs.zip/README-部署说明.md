# 村居换届选举系统 - 部署说明

## 快速启动

### Windows（推荐）
双击运行 `验证启动.bat`

### 手动启动
```bash
# 1. 启动后端
cd backend-new
npm install
npm run dev

# 2. 启动前端（新终端）
cd web
npm install
npm run dev
```

## 访问地址
- 后端API: http://localhost:3100
- 前端管理端: http://localhost:3003
- 健康检查: http://localhost:3100/health

## 环境要求

### 前置依赖
- Node.js >= 18
- PostgreSQL >= 13（支持 Supabase 云端 PostgreSQL 或本地 PostgreSQL）

### 环境变量（backend-new/.env）

**主库配置（Supabase 云端数据库，当前默认）**:
```bash
DATABASE_URL=postgresql://postgres:Zo4xia%40outlook.com@db.ydkuibtqrcohjcxmvcfm.supabase.co:5432/postgres?sslmode=verify-full&sslrootcert=supabase-ca.crt
PORT=3100
JWT_SECRET=dev-jwt-secret-key-2026
```

**本地备用库配置（开发测试环境）**:
```bash
DATABASE_URL=postgresql://postgres:123456@localhost:5432/backend_new
PORT=3100
JWT_SECRET=dev-jwt-secret-key-2026
```

**说明**: 
- 当前主后端优先直连 Supabase 云端数据库，SSL 加密保证安全
- 本地库与云端库表结构、迁移版本（3个迁移脚本）及测试账号（密码均为 123456）100% 对齐

## 数据库状态

### ✅ 核心业务铁律与 P0/P1 修复全面对齐（2026-09-08）
**修复与规则落地**:
1. positions表补列: `election_method`, `requirement`
2. announcements表补列: `template_id`, `scheduled_for`, `stage_key`
3. announcement_templates表补列: `at_sched_offset`
4. election_proposals表补列: `reject_reason`, `created_fief_id`
5. **归属地严格隔离（一人一归属地业务铁律）**: 明确禁止跨村兼任，加回 `memberships_user_id_key UNIQUE(user_id)` 锁定物理隔离；同时保留 `(user_id, organization_id)` 复合唯一约束保障 6 处 ON CONFLICT 写入幂等。
6. 候选人模块增强: 四轮联审日期窗口派生、全卷一键导出、外部送审接口
7. role_permissions补权限: 平台超管/子管理/编辑 获得 `proposal:create` 等全量权限
8. **甲方 v2 最新倒排工期与公告模板落地**: 同步第十五届 19/19 公告模板，32 条阶段 SOP 模板（村居双轨各 16 阶段），修复 D 日阶段偏移跨度塌陷为 0 天的历史 Bug。

**验证结果** (2026-09-08 实测):
```
✅ 25张表结构完整，云端 Supabase PostgreSQL 主库实测通畅
✅ P0 补列 + P1 约束与提案工作台对齐已全部落地
✅ 默认测试账号密码全量对齐为 123456（霞皋村超管: 13800000001, 涧口社区: 13800000012）
✅ 前端 3003 端口与后端 3100 端口 100% 联通且登录鉴权实测通过
```

**影响**: 提案创建/编辑/审批/选举活动主链路全线贯通

### 📋 已确认待优化项
1. **候选人审核轮次日期显示**: 表头初审/二审/联审/考察在部分旧视图中需对齐 D 日派生窗口
2. **多附件完整预览**: 前端目前优先展示首个主附件，底层支持多附件
3. **小程序 BASE_URL**: 生产发布前需将本地配置切换为生产域名或云网关地址

## 核心功能验证清单

### ✅ 已验证
- [x] 后端启动
- [x] 数据库连接
- [x] 健康检查接口

### ⚠️ 待验证（需手动测试）
- [ ] 登录（超管/村管理/经办/审核）
- [ ] 创建提案
- [ ] 审批提案（通过/驳回）
- [ ] 查看生成的活动/岗位/公告
- [ ] 候选人材料上传
- [ ] 材料审核
- [ ] 小程序登录+材料提交

## 默认账号

**所有账号密码**: 123456

| 手机号 | 角色 | 归属地 | 权限 |
|--------|------|--------|------|
| 13800000001 | 平台超管 | 霞皋村 | 全部功能 |
| 13800000002 | 子管理 | 霞皋村 | 归属地管理 |
| 13800000003 | 公告编辑 | 霞皋村 | 公告管理 |
| 13800000004 | 材料审核 | 霞皋村 | 候选人审核 |
| 13800000012 | 子管理 | 涧口社区 | 归属地管理 |

## 技术栈
- 后端: Node.js + Hono + PostgreSQL (本地)
- 前端: React + Vite + TDesign
- 数据库: PostgreSQL 13+（本地安装）

## 故障排查

### 后端无法启动
1. 检查PostgreSQL是否运行：`netstat -ano | findstr :5432`
2. 检查数据库是否存在：使用pgAdmin或psql连接
3. 检查backend-new/.env文件DATABASE_URL配置
4. 检查端口3100是否被占用（后端会自动切换到其他端口）

### 前端API调用失败
1. 确认后端已启动（检查健康检查：`curl http://localhost:3100/health`）
2. 如后端端口非3100，修改web/.env.development添加：
   ```
   VITE_API_BASE_URL=http://127.0.0.1:[实际端口]
   ```
3. 查看浏览器Console错误

### 小程序连不上
小程序未包含在当前交付包中。如需开发小程序：
1. 联系获取小程序源码
2. 修改BASE_URL为实际后端地址
3. 微信开发者工具导入项目

## 文档索引
- P0修复执行记录: `project_state/P0修复执行记录.md`
- 工程日志: `project_state/ENGINEERING_LOG.md`
- 项目状态: `project_state/PROJECT_STATE.md`
- 审核报告: 见会话记录

## 交付时间
2026-09-08

## 交付范围
- ✅ 后端源码（backend-new/）+ 启动验证通过
- ✅ 前端源码（web/）+ 启动验证通过
- ✅ 本地PostgreSQL数据库（P0修复已应用）
- ✅ 5个测试账号 + 2个组织
- ✅ 完整部署文档
- ✅ 数据库真相报告
- ✅ 全栈验证报告
- ✅ 已知问题清单（P1/P2）
- ❌ 小程序（未包含）
- ⚠️ P1/P2功能完善（待后续迭代）
