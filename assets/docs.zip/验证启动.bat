@echo off
echo === 全栈启动验证 ===
echo.

echo [1/4] 检查后端依赖...
cd backend-new
if not exist node_modules (
    echo 安装后端依赖...
    call npm install
)
cd ..

echo [2/4] 检查前端依赖...
cd web
if not exist node_modules (
    echo 安装前端依赖...
    call npm install
)
cd ..

echo [3/4] 启动后端（后台）...
set DATABASE_URL=postgresql://postgres:1ItTgkAq9b0cMb67w9@cp-super-dawn-dc46e888.pg2.aidap-global.cn-beijing.volces.com:5432/postgres?sslmode=require^&channel_binding=require
cd backend-new
start /B npm run dev
cd ..

echo [4/4] 等待5秒后启动前端...
timeout /t 5 /nobreak >nul

cd web
echo.
echo === 启动前端（按Ctrl+C停止）===
echo 后端: http://localhost:3100
echo 前端: http://localhost:5173
echo.
npm run dev
