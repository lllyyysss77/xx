@echo off
chcp 65001 >nul
echo === 村居换届选举系统 - 打包脚本 ===
echo.

set OUTPUT=交付包_%date:~0,4%%date:~5,2%%date:~8,2%

echo [1/4] 创建输出目录...
if exist "%OUTPUT%" rmdir /s /q "%OUTPUT%"
mkdir "%OUTPUT%"

echo [2/4] 复制核心文件...
xcopy /E /I /Q backend-new "%OUTPUT%\backend-new" >nul
xcopy /E /I /Q web "%OUTPUT%\web" >nul
xcopy /E /I /Q mini-program "%OUTPUT%\mini-program" >nul

echo [3/4] 复制文档...
copy README-部署说明.md "%OUTPUT%\" >nul
copy 测试验收清单.md "%OUTPUT%\" >nul
copy 交付清单.md "%OUTPUT%\" >nul
copy 验证启动.bat "%OUTPUT%\" >nul
xcopy /E /I /Q project_state "%OUTPUT%\project_state" >nul

echo [4/4] 清理node_modules...
if exist "%OUTPUT%\backend-new\node_modules" rmdir /s /q "%OUTPUT%\backend-new\node_modules"
if exist "%OUTPUT%\web\node_modules" rmdir /s /q "%OUTPUT%\web\node_modules"

echo.
echo === 打包完成 ===
echo 输出目录: %OUTPUT%
echo.
echo 目录结构:
echo %OUTPUT%\
echo   ├─ backend-new\          (后端源码)
echo   ├─ web\                  (前端源码)
echo   ├─ mini-program\         (小程序源码)
echo   ├─ project_state\        (工程文档)
echo   ├─ README-部署说明.md
echo   ├─ 测试验收清单.md
echo   ├─ 交付清单.md
echo   └─ 验证启动.bat
echo.
pause
