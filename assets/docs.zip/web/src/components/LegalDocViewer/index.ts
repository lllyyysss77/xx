export { LegalDocViewer } from './LegalDocViewer';
