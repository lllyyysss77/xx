#!/bin/bash
# 全栈快速启动验证脚本（Node版）

set -e

echo "=== 全栈启动验证（Node版）==="
echo ""

# 1. 检查环境
echo "[1/5] 检查环境..."
command -v node >/dev/null 2>&1 || { echo "需要安装 node"; exit 1; }

# 2. 检查数据库连接
echo "[2/5] 检查数据库连接..."
export DATABASE_URL="postgresql://postgres:1ItTgkAq9b0cMb67w9@cp-super-dawn-dc46e888.pg2.aidap-global.cn-beijing.volces.com:5432/postgres?sslmode=require&channel_binding=require"

# 3. 测试后端依赖
echo "[3/5] 检查后端依赖..."
if [ ! -d "backend-new/node_modules" ]; then
  echo "后端依赖未安装，安装中..."
  cd backend-new && npm install && cd ..
fi

# 4. 测试数据库连接
echo "[4/5] 测试数据库连接..."
node -e "
const { Pool } = require('pg');
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
pool.query('SELECT 1').then(() => {
  console.log('数据库连接成功 ✓');
  pool.end();
}).catch(e => {
  console.error('数据库连接失败:', e.message);
  process.exit(1);
});
" || exit 1

# 5. 检查前端
echo "[5/5] 检查前端依赖..."
if [ ! -d "web/node_modules" ]; then
  echo "前端依赖未安装，请先运行: cd web && npm install"
  exit 1
fi

echo ""
echo "=== 验证完成 ==="
echo "✓ Node环境"
echo "✓ 数据库连接"
echo "✓ 后端依赖"
echo "✓ 前端依赖"
echo ""
echo "手动启动命令:"
echo "  后端: cd backend-new && npm run dev"
echo "  前端: cd web && npm run dev"
echo ""
echo "启动后访问:"
echo "  后端: http://localhost:3100"
echo "  前端: http://localhost:5173"
