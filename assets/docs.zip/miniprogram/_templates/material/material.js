// 模板骨架 · material · 反填 backend-new 真实表字段
// 字段映射见 _templates/TEMPLATE-GUIDE.md（五、字段对照速查）
// 原则：data 仅放与 wxml 占位对应的 key，值一律 null；待定字段加 todo_ 前缀；
//       方法只留 TODO，不写死任何演示数据。

Page({
  data: {
    // —— 窗口状态（本地由日程 + 开关计算）——
    realWindowOpen: null,   // 本地:窗口开放标志（日程窗口 AND 后台开关）
    canSubmit: null,        // 本地:可提交标志
    windowState: null,      // 本地:窗口状态（before / open / after / none）
    windowMsg: null,        // 本地:窗口提示文案
    windowRange: null,      // 本地:窗口区间文案（“07-15 ~ 07-17”）
    windowHint: null,       // 本地:窗口底部提示
    submitBtnText: null,    // 本地:提交按钮文案

    // —— 材料类型清单（待定）——
    needList: [],           // 待定:材料类型清单（原 MATERIAL_TYPES 写死枚举已移除）
    needCards: [],          // 待定:材料类型 + 本地:空白表文件名

    // —— 其他可下载表格（本地静态清单）——
    extraTpl: [],           // 本地:其他可下载表格[{ name:其他表格名称, file:其他表格文件 }]

    // —— 参选岗位（positions）——
    positionList: [],       // positions.name（原 pos_type；空库兜底见后端）
    positionId: null,       // 本地:选中岗位

    // —— 上传（本地态）——
    imgFiles: [],           // 本地:图片材料列表（img-picker）
    docFiles: [],           // 本地:文件附件列表[{ name:附件名称, size:附件大小, path }]
    noteText: null,         // 本地:文字说明

    // —— 提交记录（materials + material_files）——
    records: [],            // materials：submitted_at / review_note / status / material_files（附件计数）

    // —— 后台开关（原 ann_open_material_submit，无落点 → 待定；建议改 positions.application_start/end 判断）——
    todo_materialSubmitSwitch: null, // 待定:材料提交开关（原 announcements.ann_open_material_submit；建议按 positions.application_start/end 判定）

    // —— 本地态 ——
    submitting: null,       // 本地:提交中标志
    icons: null             // 本地:图标配置（文件 / 空态 等）
  },

  onLoad() {
    // TODO: 对接 backend-new /api/materials/templates（空白表清单）
  },

  onShow() {
    // TODO: 对接 backend-new /api/mp/materials（我的提交记录，按 users.phone 过滤 mat_applicant_id）
  },

  refresh() {
    // TODO: 对接 backend-new 取 positions(application_start/end 判窗口) + materials(我的记录)
    //       计算 realWindowOpen / canSubmit / windowState / records 等本地态。
  },

  onPickPosition(e) {
    // TODO: 对接 backend-new 选择参选岗位（positions.name）
  },

  downloadTpl(e) {
    // TODO: 对接 backend-new GET /api/files/material_templates/<file>
  },

  onNoteInput(e) {
    // TODO: 对接 backend-new 文字说明输入（本地态）
  },

  // ============ img-picker（拍照 / 相册图片）============
  onImgAdd(e) {
    // TODO: 对接 backend-new 图片添加（本地态）
  },
  onImgRemove(e) {
    // TODO: 对接 backend-new 图片移除（本地态）
  },
  onUploadFail(e) {
    // TODO: 对接 backend-new 图片选择失败提示（本地态）
  },

  // ============ 文件附件（自增多个）============
  addDocFile() {
    // TODO: 对接 backend-new 选择文件附件（本地态）
  },
  removeDocFile(e) {
    // TODO: 对接 backend-new 移除文件附件（本地态）
  },

  submit() {
    // TODO: 对接 backend-new POST /api/mp/materials（positionId + note）+ /api/materials/:id/upload（multipart 附件）
    //       注意：参选人端用 /api/mp/*（无 requireStaff），勿用 staff 内推端点。
  }
})
