/* ───────────────────────────────────────────────────────────────────────
 * profile 页 · 挖空模板骨架（待 backend-new 真实表字段反填）
 * 原 pages/profile/profile.js 仅作 data 结构参考，未改动。
 *
 * 字段映射速查（详见 _templates/TEMPLATE-GUIDE.md）：
 *   users.display_name            ← 账号名 / 参选人姓名（原 acc_name / cand_name）
 *   users.phone                   ← 信息网格「手机号」（info.value 之一）
 *   candidates.status             ← 参选档案状态（原 cand_status）
 *   positions.name                ← 参选档案岗位（原 cand_position_id）
 *   materials.submitted_at/status ← 我的提交材料（原 mat_submit_time/mat_status）
 *   待定:组织名称/角色标签/候选人来源/材料名称/未读公告数 ← 新主库无落点
 *   本地:头像首字/是否游客/信息标签/上传* / 图标 ← 纯前端态
 *   🚫 notifications / notification_reads 两表整块无落点 → 未读红点整块 {{待定:未读公告数}}
 * ─────────────────────────────────────────────────────────────────────── */

Page({
  data: {
    isGuest: false,                // 本地:是否游客（控制头像/姓名兜底文案）
    users: { display_name: null }, // 详情:账号名；display_name→users.display_name
    todo_orgName: null,            // 待定:组织名称（organizations 无清晰落点）
    todo_roleLabel: null,          // 待定:角色标签（memberships.role 无落点）
    todo_unreadCount: null,        // 待定:未读公告数（notifications 整表无落点）
    info: [],                      // 列表:信息网格；icon/label→本地，value→users.phone / 待定:组织名称 / 本地
    myCand: null,                  // 详情:参选档案；name→users.display_name / position→positions.name / status→candidates.status / source→待定
    materialList: [],              // 列表:我的材料；date→materials.submitted_at / status→materials.status / name→待定:材料名称
    materialTotal: 0,              // 本地:材料总数
    uploads: []                    // 列表:本机上传（纯前端 7 日 TTL）；name/sizeText/timeText→本地
  },

  // TODO: 对接 backend-new /users（display_name / phone）
  // TODO: 对接 backend-new /candidates（参选档案：users.display_name + positions.name + candidates.status）
  // TODO: 对接 backend-new /materials（提交记录：submitted_at / status）
  // TODO: 对接 backend-new /notifications（未读红点，当前无落点，先待定）

  goCandidate() {},
  goNotice() {},
  goMaterial() {},
  addUpload() {},
  removeUpload() {}
})
