# 小程序挖空模板规范（TEMPLATE-GUIDE）

> 目的：把 `pages/` 的 7 个页面掏成**与数据库对症**的空模板，后续按 `backend-new` 真实表字段反填。
> 铁律：**原 `pages/` 一律不动**，产物只写进 `miniprogram/_templates/<页面名>/`。

## 一、占位符语法（四级）

| 语法 | 何时用 | 示例 |
|---|---|---|
| `{{表名.字段名}}` | 新主库有直接落点 | `{{election_fiefs.d_day}}` |
| `{{表名.字段名\|转换:说明}}` | 有落点但要转换 | `{{election_fief_stages.start_date\|需由D日反推偏移}}` |
| `{{待定:中文含义}}` | 业务必需但新主库无落点 | `{{待定:候选人性别}}` |
| `{{本地:含义}}` | 纯前端态/写死配置，不依赖库 | `{{本地:快捷入口图标配置}}` |

**红线字段不挖空、直接删绑定**，原位置留一行注释：
```xml
<!-- 🚫 红线A-002：原 {{cand_votes}}（得票）已废弃，不做线上投票/计票 -->
```

## 二、区块注释（每个逻辑块前必加）

```xml
<!-- ▼ 区块名 · 数据源: 表名 · 消费字段: a, b, c -->
```

## 三、JS 骨架要求

- `data: {}` 里放与 wxml 占位对应的 key，值一律 `null`，行注释标来源：
  `dDay: null,          // election_fiefs.d_day`
- 待定字段 key 前加 `todo_` 前缀：`todo_gender: null,  // 待定:候选人性别`
- 网络方法只留 `// TODO: 对接 backend-new <路由>`，不写死任何演示数据

## 四、掏空时的优化点（夏夏指令）

1. 版式归四类：**列表页 / 详情页 / 表单页 / 时间轴页**，同类结构尽量一致
2. 列表项统一叫 `item`，详情统一叫 `detail`，不再各页各叫一套
3. 写死的演示数据、假角色、假组织一律不留
4. 每个 wxml 头部加一行：`<!-- 模板状态: 挖空待填 | 原版: pages/<页名>/ | 2026-09-04 -->`

## 五、字段对照速查（新主库实测列名，2026-09-04）

| 小程序字段 | 新主库落点 | 状态 |
|---|---|---|
| `el_name` | `election_fiefs.name` | ✅ |
| `el_election_date` | `election_fiefs.d_day` | ✅ |
| `el_method` / `el_note` | 无 | ❌ 待定 |
| `es_stage_name` | `election_fief_stages.stage_name` | ✅ |
| `es_offset_start/end` | `election_fief_stages.start_date/end_date` | 🔁 需D日反推 |
| `es_status` | `election_fief_stages.status` | 🔁 pending/ongoing/completed→中文 |
| `es_note` | `stage_templates.st_description` | 🔁 经模板关联 |
| `ann_title` / `ann_content` | `announcements.title` / `body` | ✅ |
| `ann_publish_time` | `announcements.published_at` | ✅ |
| `ann_code` | `announcement_templates.at_code` | 🔁 经 template_id |
| `ann_pin` / `ann_type` | 无（本地演示列） | {{本地:}} |
| `ann_files` | 无 | ❌ 待定:公告附件 |
| `cand_name` | `users.display_name` | 🔁 |
| `cand_gender/age/source/note` | 无 | ❌ 待定 |
| `cand_position_id` | `positions.name` | 🔁 |
| `cand_status` | `candidates.status` + `current_round` | 🔁 |
| `cand_votes` | — | 🚫 红线删除 |
| `cand_r1~r4(含reviewer/time/comment)` | `candidate_reviews(round/decision/note/reviewer_id/created_at)` | 🔁 纵转横 |
| `mat_type` | 无 | ❌ 待定:材料类型 |
| `mat_status` | `materials.status` | ✅ |
| `mat_submit_time` | `materials.submitted_at` | ✅ |
| `mat_review_comment` | `materials.review_note` | ✅ |
| `mat_attachments` | `material_files(file_name/mime_type/size_bytes/storage_key)` | 🔁 |
| `mat_applicant_id` | `materials.candidate_user_id` | 🔁 |
| `pos_type` | `positions.name` | 🔁 |
| `pos_quota` / `pos_status` | `positions.quota` / `status` | ✅ |
| `pos_desc` | 无 | ❌ 待定 |
| 报名窗口 | `positions.application_start / application_end` | ✅ |
| `acc_phone` | `users.phone` | 🔁 |
| `acc_name` | `users.display_name` | 🔁 |
| `acc_password_hint` | `users.password_hash` | 🔁（旧明文→新scrypt） |
| `account_roles.ar_role_key` | `memberships.role` | 🔁 |
| `roles.role_key/role_name` | `roles.key/name` | 🔁 |
| `organizations.town` | 无 | ❌ 待定:镇街 |
| `organizations.type` | `organizations.org_type` | 🔁 |
| `roster.ros_*` | 无 roster 表 | ❌ 待定 |
| `notifications.notif_*` / `nr_*` | 无 | ❌ 待定 |
| `election_results.er_*` | 无 | ❌ 待定（涉红线见下） |
| `er_actual_voters / er_turnout / er_eligible_voters` | 无 | 🚫 红线待裁决，先删 |
