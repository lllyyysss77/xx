// 模板骨架 · login · 反填 backend-new 真实表字段
// 字段映射见 _templates/TEMPLATE-GUIDE.md（五、字段对照速查）
// 原则：data 仅放与 wxml 占位对应的 key，值一律 null；待定字段加 todo_ 前缀；
//       方法只留 TODO，不写死任何演示数据、假角色、假组织。

Page({
  data: {
    // —— 品牌区 ——
    platformName: null,    // organizations.name（平台根组织 name，原写死“城厢区换届选举平台”已移除）
    platformDept: null,    // 待定:主管单位（原 organizations.org_note 推断，新主库待确认落点）

    // —— 归属地（organizations）——
    orgNames: [],          // 本地:归属地名称列表（organizations.name）
    orgIndex: null,        // 本地:选中归属地索引（-1 = 未选）
    orgLocked: null,       // 本地:归属地锁定标志（本机已绑定账号后不可改）

    // —— 账号（users，原 accounts）——
    phone: null,           // users.phone（原 acc_phone）
    password: null,        // 本地:密码输入（对照 users.password_hash，原 acc_password_hint，明文→scrypt）

    // —— 身份（memberships + roles，原 account_roles + roles）——
    role: null,            // 本地:选中角色（memberships.role，原 ar_role_key）
    roleList: [],          // 本地:可用角色列表[{ role: memberships.role, name: roles.name }]
    isGuest: null,         // 本地:游客标志（未注册 / 无可用角色兜底）
    isUnregistered: null,  // 本地:未注册标志（users 中无该手机号）

    // —— 本地态 ——
    error: null,           // 本地:错误提示
    loading: null,         // 本地:登录加载标志
    icons: null            // 本地:图标配置（定位 / 用户 / 锁 / 微信）
  },

  onLoad() {
    // TODO: 对接 backend-new /api/orgs（GET 免登录，归属地=全部村/社区）+ /api/organizations(平台根组织 name)
  },

  onOrgChange(e) {
    // TODO: 对接 backend-new 归属地下拉变更（联动刷新 memberships 角色）
  },

  onPhone(e) {
    // TODO: 对接 backend-new 手机号输入（触发 _refreshRoles）
  },

  onPassword(e) {
    // TODO: 对接 backend-new 密码输入（本地态，不落库）
  },

  onRole(e) {
    // TODO: 对接 backend-new 角色选择（更新 memberships.role 选中态）
  },

  submit() {
    // TODO: 对接 backend-new POST /api/login（org_id + phone + password）或 POST /api/mp/login（免密）
  },

  quickLogin() {
    // TODO: 对接 backend-new POST /api/mp/wxlogin（wx.login code → openid → token）
  }
})
