// 模板骨架 · home · 反填 backend-new 真实表字段
// 字段映射见 _templates/TEMPLATE-GUIDE.md（五、字段对照速查）
// 原则：data 仅放与 wxml 占位对应的 key，值一律 null；待定字段加 todo_ 前缀；
//       方法只留 TODO，不写死任何演示数据。

Page({
  data: {
    // —— 公告（走马灯最新一条 + 列表）——
    announcements: null,   // announcements.title / ann_code / published_at（走马灯取最新一条）
    latestAnns: [],        // announcements 列表：ann_code / title / published_at / 置顶 / 类型 / 新标

    // —— 选举主表 ——
    electionName: null,    // election_fiefs.name（原 el_name）
    dDay: null,            // election_fiefs.d_day（原 el_election_date）

    // —— 组织 ——
    orgName: null,         // organizations.name（原 org.name）

    // —— 阶段（election_fief_stages）——
    currentStage: null,    // 本地:当前阶段标志（由 election_fief_stages 计算）
    nextStage: null,       // 本地:近期预告标志
    stageName: null,       // election_fief_stages.stage_name
    stageStart: null,      // election_fief_stages.start_date | 需由D日反推偏移
    stageEnd: null,        // election_fief_stages.end_date   | 需由D日反推偏移

    // —— 纯前端态（本地计算）——
    daysToD: null,         // 本地:距D日天数（由 election_fiefs.d_day 计算）
    progressDone: null,    // 本地:换届整体进度百分比

    // —— 四宫格入口（本地导航配置）——
    grid: [],              // 本地:四宫格入口[{ label:入口名称, url:入口路由, ic:入口图标, dot:入口未读红点 }]

    // —— 村/居委会干部花名册（整表无落点，全待定）——
    todo_roster: [],       // 待定:花名册列表（姓名 / 职位 / 简介 / 联系方式 / 届期）

    // —— 图标（本地静态资源）——
    icons: null            // 本地:图标配置（走马灯 / 日历 / 定位 / 空态 / 入口 等）
  },

  onShow() {
    // TODO: 对接 backend-new /api/elections/:id（含 election_fief_stages）+ /api/announcements + /api/organizations
  },

  refresh() {
    // TODO: 对接 backend-new 取 election_fiefs / election_fief_stages / announcements / organizations，
    //       计算 currentStage / nextStage / daysToD / progressDone / grid 本地态。
  },

  goGrid(e) {
    // TODO: 对接 backend-new 本地入口配置路由跳转（grid[].url）
  },

  goNotice() {
    // TODO: 对接 backend-new 跳转 /pages/notice
  },

  goAnnDetail(e) {
    // TODO: 对接 backend-new 公告详情（announcements.ann_code = e.currentTarget.dataset.code）
  }
})
