/* ───────────────────────────────────────────────────────────────────────
 * method 页 · 挖空模板骨架（待 backend-new 真实表字段反填）
 * 原 pages/method/method.js 仅作 data 结构参考，未改动。
 *
 * 字段映射速查（详见 _templates/TEMPLATE-GUIDE.md）：
 *   election_fiefs.d_day          ← 投票日（原 el_election_date）
 *   positions.name / .quota       ← 岗位名 / 职数（原 pos_type / pos_quota）
 *   election_fief_stages.*         ← 阶段网格（stage_key/name/start_date/status，按 D 日反推）
 *   待定:选举方式 / 岗位说明 / 选举届次 / 届次选项* / 材料* ← 新主库无落点
 *   本地:当前Tab类/岗位数/岗总职数/进度/报名表文本/图标 ← 纯前端态
 * ─────────────────────────────────────────────────────────────────────── */

Page({
  data: {
    todo_electionOptions: null,    // 待定:届次选项列表（elections）
    electionIndex: 0,              // 本地:届次选中索引
    selectedElection: null,        // 待定:届次选项对象（term/label/date，仅作非空判断与标签源）
    todo_electionMethodText: null, // 待定:选举方式（el_method 无落点）
    positions: [],                 // 列表:岗位卡；item.name→positions.name / item.quota→positions.quota / item.desc→待定:岗位说明
    positionTotal: 0,              // 本地:岗位总职数
    stages: [],                    // 列表:阶段网格；item.*→election_fief_stages.*
    stageDone: 0,                  // 本地:已完成阶段数
    progressPct: 0,                // 本地:进度百分比
    currentStageName: '',          // 本地:当前阶段名
    // 报名表弹窗
    formVisible: false,            // 本地:弹层显隐
    formText: '',                  // 本地:报名表模板文本
    todo_formPosition: null,       // 待定:报名岗位
    // 岗位说明弹窗
    descVisible: false,            // 本地:弹层显隐
    todo_descTitle: null,          // 待定:岗位说明标题
    todo_descText: null,           // 待定:岗位说明文本
    // 材料下载弹窗
    matVisible: false,             // 本地:弹层显隐
    todo_matPos: null,             // 待定:材料岗位
    todo_matList: null             // 待定:材料模板列表（name/desc 均无落点）
  },

  // TODO: 对接 backend-new /elections（届次列表 + 投票日 d_day + 选举方式待定）
  // TODO: 对接 backend-new /positions（岗位名 name / 职数 quota；岗位说明待定）
  // TODO: 对接 backend-new /stages（election_fief_stages，按 D 日反推 start_date）

  pickElection() {},
  goQuickSubmit() {},
  closeSheet() {},
  copyForm() {},
  showPosDesc() {},
  openFormFromDesc() {},
  openMaterials() {},
  copyMaterial() {}
})
