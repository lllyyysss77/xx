/* ───────────────────────────────────────────────────────────────────────
 * candidate 页 · 挖空模板骨架（待 backend-new 真实表字段反填）
 * 原 pages/candidate/candidate.js 仅作 data 结构参考，未改动。
 *
 * 字段映射速查（详见 _templates/TEMPLATE-GUIDE.md）：
 *   election_fiefs.name          ← 页头届次名（原 activeElectionName）
 *   positions.name / .quota      ← 岗位名 / 职数（原 groups[].title / .quota）
 *   users.display_name           ← 候选人姓名（原 cand_name）
 *   candidates.status            ← 审核状态（原 cand_status，含 +current_round）
 *   candidate_reviews.*           ← 四轮审核（round/decision/note/reviewer_id/created_at，纵转横）
 *   待定:候选人性别/年龄/来源/备注  ← cand_gender/age/source/note 新主库无落点
 *   本地:公示概要文案/岗位序号/阶段文案/缺额/头像首字/图标  ← 纯前端派生
 *   🚫 红线A-002：cand_votes（得票）已废弃，模板中不保留任何绑定
 * ─────────────────────────────────────────────────────────────────────── */

Page({
  data: {
    icons: null,          // 本地:图标静态资源（wxss 复用，src 直接 {{本地:图标file}}）
    groups: [],           // 列表：岗位容器；item.name→positions.name / item.quota→positions.quota / item.members→candidates(users.display_name)
    detail: null,         // 详情：候选人明细；name→users.display_name / position→positions.name / status→candidates.status / gender·age·source·note→待定
    detailRounds: []      // 详情：四轮审核（纵转横）；每项 = candidate_reviews 一行（decision/created_at/reviewer_id/note + 本地 label/cls）
  },

  // TODO: 对接 backend-new /elections（取当前届次名 election_fiefs.name）
  // TODO: 对接 backend-new /positions（取岗位名+职数 positions.name/quota）
  // TODO: 对接 backend-new /candidates（取公示名单 users.display_name + candidates.status + 四轮 candidate_reviews）

  openDetail() {},
  closeDetail() {}
})
