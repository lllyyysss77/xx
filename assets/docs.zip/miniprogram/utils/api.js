// utils/api.js — 小程序端 HTTP 客户端（配套后端 = backend-new，端口 3100）
// 设计原则（与「真实优先 / 离线不可达如实提示」一致）：
//   1) 优先读取本地/平台配置服务地址，最差自动降级回退到 http://127.0.0.1:3100（绝不硬编码死）；
//   2) 网络失败 e.type='network' → 如实提示「后端不可达」，不再回落假数据；
//   3) 401 自动清 token（下次登录重新获取）。
const DEFAULT_BASE_URL = 'http://127.0.0.1:3100'

function hasWx() { return typeof wx !== 'undefined' }

/** 获取动态 Base URL：优先读本地存储，兜底默认 127.0.0.1:3100 */
function getBaseUrl() {
  if (!hasWx()) return DEFAULT_BASE_URL
  const custom = wx.getStorageSync('customApiBaseUrl')
  return (custom && String(custom).trim()) || DEFAULT_BASE_URL
}

/** 设置动态 Base URL（供调试或现场配置生产域名使用） */
function setBaseUrl(url) {
  if (!hasWx()) return
  if (url && String(url).trim()) wx.setStorageSync('customApiBaseUrl', String(url).trim())
  else wx.removeStorageSync('customApiBaseUrl')
}

const TOKEN_KEY = 'mpToken'
function getToken() { return (hasWx() && wx.getStorageSync(TOKEN_KEY)) || '' }
function setToken(t) { if (!hasWx()) return; if (t) wx.setStorageSync(TOKEN_KEY, t); else wx.removeStorageSync(TOKEN_KEY) }
function clearToken() { setToken('') }

function err(type, message) { const e = new Error(message); e.type = type; return e }

/** 底层请求：wx.request → Promise；兼容新后端裸数组 / 裸对象 */
function request(method, path, body, opts) {
  opts = opts || {}
  const baseUrl = getBaseUrl()
  return new Promise((resolve, reject) => {
    wx.request({
      url: baseUrl + path,
      method,
      data: body || undefined,
      timeout: opts.timeout || 5000,
      header: Object.assign(
        { 'Content-Type': 'application/json' },
        getToken() ? { Authorization: 'Bearer ' + getToken() } : {}
      ),
      success(res) {
        if (res.statusCode >= 200 && res.statusCode < 300) {
          const j = res.data
          if (j && typeof j === 'object' && j.code !== undefined) {
            if (j.code === 0) resolve(j.data)
            else reject(err('http', j.message || '业务处理失败'))
          } else {
            resolve(j)
          }
        } else if (res.statusCode === 401) {
          clearToken()
          reject(err('auth', (res.data && res.data.message) || '登录已过期，请重新登录'))
        } else {
          reject(err('http', (res.data && res.data.message) || ('请求失败（' + res.statusCode + '）')))
        }
      },
      fail() { reject(err('network', '后端不可达（未启动或不在同一网络）')) },
    })
  })
}

function get(path, opts) { return request('GET', path, null, opts) }
function post(path, body, opts) { return request('POST', path, body, opts) }
function put(path, body, opts) { return request('PUT', path, body, opts) }

/** 参选人密码登录：POST /auth/candidate/login { phone, password, organizationId }
 *  仅 candidate 角色可登；成功返回 { token, organizationId, role, ... }。 */
function login(phone, password, organizationId) {
  return post('/auth/candidate/login', { phone, password, organizationId }, { timeout: 6000 })
}

/** 参选人密码注册：POST /auth/register { phone, password, displayName, organizationId }
 *  后端硬编码 role=candidate（注册即绑死归属地），返回含 token。 */
function register(phone, password, displayName, organizationId) {
  return post('/auth/register', { phone, password, displayName, organizationId }, { timeout: 8000 })
}

/** 附件真实上传（wx.uploadFile → multipart）：POST /files/upload（字段名 file，
 *   formData 可带 electionFiefId/sourceType）→ 返回文件元数据（含 storage_key）。
 *  与 request() 同一套错误分类（network/auth/http）；兼容无 {code:0} 包裹的裸元数据响应。 */
function uploadFile(path, filePath, formData) {
  return new Promise((resolve, reject) => {
    if (!getToken()) return reject(err('auth', '未登录（无 token），请先登录'))
    const baseUrl = getBaseUrl()
    wx.uploadFile({
      url: baseUrl + path,
      filePath: filePath,
      name: 'file',
      header: { Authorization: 'Bearer ' + getToken() },
      formData: formData || {},
      timeout: 20000,
      success(res) {
        let j = null
        try { j = typeof res.data === 'string' ? JSON.parse(res.data) : res.data } catch (e) { j = null }
        if (res.statusCode >= 200 && res.statusCode < 300) {
          if (j && typeof j === 'object' && j.code !== undefined) {
            if (j.code === 0) resolve(j.data)
            else reject(err('http', j.message || '上传失败'))
          } else {
            // 新后端 /files/upload 返回裸元数据（无 code 包裹），直接透传
            resolve(j)
          }
        } else if (res.statusCode === 401) {
          clearToken()
          reject(err('auth', (j && j.message) || '登录已过期，请重新登录'))
        } else {
          reject(err('http', (j && j.message) || ('上传失败（' + res.statusCode + '）')))
        }
      },
      fail() { reject(err('network', '后端不可达（上传中断）')) },
    })
  })
}

module.exports = { getBaseUrl, setBaseUrl, DEFAULT_BASE_URL, getToken, setToken, clearToken, get, post, put, login, register, uploadFile }
