const { DB } = require('../../data/db')
const icons = require('../../utils/icons')

/* ───────────────────────────────────────────────────────────────────────
 * 村居换届选举系统 · 参选人登录页
 * 后端 = backend-new（3100）。小程序端仅参选人（candidate）一种角色：
 *   - 登录：POST /auth/candidate/login { phone, password, organizationId }
 *   - 注册：POST /auth/register { phone, password, displayName, organizationId }
 *     （后端硬编码 role=candidate，注册即绑死归属地，与免密/游客/微信登录无关——这些概念已全部移除）
 * 铁律：不要假数据。归属地列表走真实接口 GET /auth/organizations，不再回落本地演示组织。
 * ─────────────────────────────────────────────────────────────────────── */

Page({
  data: {
    icons: icons.dai,
    platformName: '城厢区换届选举平台',
    platformDept: '城厢区民政局',
    phone: '',
    password: '',
    orgIndex: -1,        // -1 = 未选择；归属地强制必选
    orgs: [],             // [{ id, slug, name }]（来自 GET /auth/organizations）
    orgNames: [],
    error: '',
    loading: false
  },

  onLoad() {
    const app = getApp()
    // 品牌区：平台根组织名优先从真实归属地列表取（slug='boss'），否则用兜底文案
    require('../../utils/api').get('/auth/organizations', { timeout: 4000 }).then((rows) => {
      const list = require('../../data/map').mapOrgs(rows || [])
      this.setData({ orgs: list, orgNames: list.map(o => o.name) })
      const boss = list.find(o => o.slug === 'boss')
      if (boss && boss.name) this.setData({ platformName: boss.name })
    }).catch(() => { /* 离线：归属地列表为空，提交时如实提示需联网 */ })
  },

  onPhone(e) { this.setData({ phone: e.detail.value, error: '' }) },
  onPassword(e) { this.setData({ password: e.detail.value, error: '' }) },
  onOrgChange(e) {
    const v = e && e.detail && e.detail.value
    if (v !== undefined) this.setData({ orgIndex: Number(v), error: '' })
  },

  /* 当前选中的归属地对象（含 id 作为 organizationId） */
  _selOrg() {
    const { orgs, orgIndex } = this.data
    return (orgIndex >= 0 && orgs[orgIndex]) ? orgs[orgIndex] : null
  },

  /* 密码登录：POST /auth/candidate/login（phone + password + organizationId） */
  submit() {
    if (this.data.loading) return
    const { phone, password } = this.data
    const org = this._selOrg()
    if (!org) return this.setData({ error: '请先选择归属地' })
    if (!/^1\d{10}$/.test(phone || '')) return this.setData({ error: '手机号格式不正确（11 位数字）' })
    if (!password) return this.setData({ error: '请输入密码（注册时设置的密码）' })
    this.setData({ loading: true, error: '' })
    wx.showLoading({ title: '登录中…', mask: true })
    require('../../utils/api').login(phone, password, org.id).then((result) => {
      wx.hideLoading()
      this.setData({ loading: false })
      this._enter(result, org, phone)
    }).catch((e) => {
      wx.hideLoading()
      this.setData({ loading: false })
      // 服务端明确拒绝（密码错/账号停用/非 candidate 角色）：如实提示，不静默降级
      this.setData({ error: (e && e.message) || '登录失败' })
    })
  },

  /* 密码注册：POST /auth/register（phone + password + displayName + organizationId）
   * 后端硬编码 role=candidate，归属地注册后由服务端锁死，前端不另造锁定逻辑。 */
  register() {
    if (this.data.loading) return
    const { phone, password } = this.data
    const org = this._selOrg()
    if (!org) return this.setData({ error: '请先选择归属地' })
    if (!/^1\d{10}$/.test(phone || '')) return this.setData({ error: '手机号格式不正确（11 位数字）' })
    if (!password || password.length < 6) return this.setData({ error: '请设置至少 6 位密码' })
    this.setData({ loading: true, error: '' })
    wx.showLoading({ title: '注册中…', mask: true })
    require('../../utils/api').register(phone, password, phone, org.id).then((result) => {
      wx.hideLoading()
      this.setData({ loading: false })
      wx.showToast({ title: '注册成功，已自动登录', icon: 'success', duration: 1500 })
      this._enter(result, org, phone)
    }).catch((e) => {
      wx.hideLoading()
      this.setData({ loading: false })
      // 跨归属地重复注册 / 已注册等：如实提示，绝不静默降级
      this.setData({ error: (e && e.message) || '注册失败' })
    })
  },

  /* 登录/注册成功后：写本地会话态 → 同步后端数据 → 进首页 */
  _enter(result, org, phone) {
    const app = getApp()
    const acc = {
      acc_phone: phone, acc_name: (result && result.displayName) || phone,
      acc_org_id: '', acc_status: 'active', roles: ''
    }
    // 归一结果对象：backend-new 返回 { token, organizationId, role, displayName }
    const norm = {
      token: result.token,
      organizationId: (result.organizationId) || (result.orgId) || org.id,
      role: result.role || 'candidate',
      displayName: result.displayName || phone,
      accName: result.displayName || phone,
      orgName: '',
      phone: phone
    }
    app.login(acc, 'candidate', '')
    app.serverLogin(norm, phone).then(goHome).catch(goHome) // 同步失败不阻断：如实空态
    function goHome() { wx.switchTab({ url: '/pages/home/home' }) }
  }
})
