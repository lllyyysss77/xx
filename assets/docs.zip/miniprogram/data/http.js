// data/http.js — 服务端数据同步编排：登录后拉全量可见表 → map 归一 → 原位覆盖 DB
// 与 data/source.js（云开发/本地兜底）共用一套合并策略：Object.assign(db.DB, 表) 顶层引用不变，
// 全部页面 require('../../data/db').DB 零改动即可看到后端最新数据。
// 数据流：登录拿 token → syncAll 拉取 → 映射 → DB 覆盖 → 当前页 rerender()。
// 后端 = backend-new（3100），所有 GET 均带 Bearer token；数据按候选人所绑归属地自动过滤（单归属地口径）。
const api = require('../utils/api')
const map = require('./map')
const dbm = require('./db')
const CACHE_KEY = 'electionRemoteCache' // 与 source.js 同键：启动秒开上次同步结果

let syncing = false

/** 当前页面刷新钩子：同步完成后调用栈顶页面的 refresh()（业务页都有），
 *  保证用户停在页面上也能看到刚拉下来的新数据，不必等下一次 onShow。 */
function rerender() {
  if (typeof getCurrentPages !== 'function') return
  const pages = getCurrentPages()
  const top = pages && pages[pages.length - 1]
  if (top && typeof top.refresh === 'function') {
    try { top.refresh() } catch (e) { /* 页面刷新异常不影响数据同步结果 */ }
  }
}

/** 登录归属地（优先全局会话，兜底存储的服务端会话） */
function currentOrgId() {
  const g = (typeof getApp === 'function' && getApp() && getApp().globalData) || {}
  if (g.orgId) return g.orgId
  const auth = (typeof wx !== 'undefined' && wx.getStorageSync('mpAuth')) || null
  return (auth && auth.orgId) || ''
}

/** 拉取并合并全部可见表。要求已登录（token 在位）。
 *  抛错：e.type='auth'（token 过期，已被 api 层清除）/ 'network'（后端不可达）/ 'http'。
 *  并发控制：wx.request 并发上限 10，取 3 一批分批放行，阶段表按届次逐个拉。 */
async function syncAll() {
  if (syncing) return false
  if (!api.getToken()) { const e = new Error('未登录（无 token）'); e.type = 'auth'; throw e }
  syncing = true
  try {
    // 批1：归属地清单（免登录契约同源，但走已登录态亦可）、本届选举、健康检查
    const batch1 = await Promise.all([
      api.get('/auth/organizations'), api.get('/candidate/elections'), api.get('/health'),
    ])
    const orgs = batch1[0]
    const elections = batch1[1]
    const health = batch1[2]

    const mapped = {
      organizations: map.mapOrgs(orgs),
      elections: map.mapElections(elections),
    }

    // 各届阶段逐届拉取（村级账号通常 1~2 届）。
    // 契约：/candidate/elections 返回蛇形裸数组，主键是 id（非 elId）；
    //       /candidate/elections/:id/stages 直接返回数组，需把该届 D 日(el_election_date)一起传给 mapStages 反推偏移
    const stageRows = []
    for (const el of (elections || [])) {
      const rows = await api.get('/candidate/elections/' + encodeURIComponent(el.id) + '/stages')
      stageRows.push.apply(stageRows, map.mapStages(rows, el.d_day, orgIdForStage(), el.id))
    }
    mapped.election_stages = stageRows

    // 批2：公告 / 岗位 / 我的材料 / 候选人列表（均为候选人口径，token 自动过滤归属地）
    const batch2 = await Promise.all([
      api.get('/candidate/announcements'),
      api.get('/candidate/positions'),
      api.get('/candidate/materials'),
      api.get('/candidate/candidates').catch(() => [])
    ])
    const currentElectionId = (elections && elections[0] && elections[0].id) || ''
    const ctxParams = { orgId: currentOrgId(), electionId: currentElectionId, phone: callerPhone() }

    mapped.announcements = map.mapAnnouncements(batch2[0])
    // 补齐公告的 org/election 所属
    mapped.announcements.forEach(a => {
      if (!a.ann_org_id) a.ann_org_id = ctxParams.orgId
      if (!a.ann_election_id) a.ann_election_id = ctxParams.electionId
    })

    mapped.positions = map.mapPositions(batch2[1])
    mapped.positions.forEach(p => {
      if (!p.pos_org_id) p.pos_org_id = ctxParams.orgId
      if (!p.pos_election_id) p.pos_election_id = ctxParams.electionId
    })

    mapped.materials = map.mapMaterials(batch2[2], ctxParams)
    mapped.materials.forEach(m => {
      if (!m.mat_org_id) m.mat_org_id = ctxParams.orgId
      if (!m.mat_election_id) m.mat_election_id = ctxParams.electionId
    })

    mapped.candidates = map.mapCandidates(batch2[3])
    mapped.candidates.forEach(c => {
      if (!c.cand_org_id) c.cand_org_id = ctxParams.orgId
      if (!c.cand_election_id) c.cand_election_id = ctxParams.electionId
    })

    // 原位覆盖（单一 DB 引用，页面零改动生效）+ 落缓存（下次启动秒开）
    Object.assign(dbm.DB, mapped)
    if (typeof wx !== 'undefined') wx.setStorageSync(CACHE_KEY, mapped)

    // 在线模式「今日」= 服务端今日：倒计时 / 阶段状态与后端同一时钟
    const app = typeof getApp === 'function' ? getApp() : null
    if (app && app.globalData) {
      app.globalData.serverMode = true
      if (health && health.today) app.globalData.snapshotDate = health.today
      // 选举届次切换：后端只回传本归属地届次，选「进行中」优先、否则取第一条作为当前届
      const list = mapped.elections || []
      const active = list.find((e) => e.el_status === 'in_progress') || list[0]
      app.globalData.electionId = active ? active.el_id : ''
    }
    rerender()
    return true
  } finally {
    syncing = false
  }
}

// 阶段表归属地占位：后端按 token 已过滤，阶段行 org 字段置空即可（页面按届次过滤，不依赖 org）
function orgIdForStage() { return '' }
// 材料归属手机号（来自会话存储，materials 表 mat_applicant_id 对齐用）
function callerPhone() {
  const auth = (typeof wx !== 'undefined' && wx.getStorageSync('mpAuth')) || null
  return (auth && auth.phone) || (typeof getApp === 'function' && getApp() && getApp().globalData && getApp().globalData.account && getApp().globalData.account.acc_phone) || ''
}

module.exports = { syncAll, rerender }
