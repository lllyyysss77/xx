// data/map.js — 服务端 API 响应 → 小程序 db.js 行（字段名 + 取值口径归一）
// 这是「后端设置 → 小程序可见」数据一致性的唯一翻译层。
//
// ⚠️ 关键契约（backend-new，3100 端口，实测）：
//   后端所有接口返回蛇形裸数组 / 裸对象（无 {code,data} 包裹、无驼峰别名），
//   如 /candidate/elections → [{id, name, d_day, status, term_name}]。
//   因此本文件 from 一律写蛇形。to 字段（小程序蛇形口径 el_name/ann_code/...）一律不动——页面全靠它们。
//
// 模板化：映射由下方 SCHEMA 声明式配置驱动，适配新系统只改 SCHEMA，不新增函数。
const { parseDate } = require('../utils/dates')

/* ── 标量归一（转换器，供 SCHEMA.fn 引用） ── */
// 时间戳归一：'2026-07-20 10:00:00+00' / '2026-07-20T10:00:00.000Z' → '2026-07-20 10:00'
const ts = (v) => (v ? String(v).slice(0, 16).replace('T', ' ') : '')
const day = (v) => (v ? String(v).slice(0, 10) : '')
const s = (v) => (v === null || v === undefined ? '' : v)
// 偏移天数：相对 D 日（b - a），把服务端真实日期还原成 D 偏移量
function offsetFrom(dDay, dateStr) {
  const a = parseDate(day(dDay))
  const b = parseDate(day(dateStr))
  if (!a || !b) return 0
  return Math.round((b.getTime() - a.getTime()) / 86400000)
}
// 阶段状态归一：后端存中文「未开始/进行中/已完成」，小程序全站口径是「未开始/办理中/已完成」，
// 阶段状态归一：后端存中文「未开始/进行中/已完成」，小程序全站口径是「未开始/办理中/已完成」，
// 仅「进行中」需改写成「办理中」（其余同名直传）。历史英文值（pending/ongoing/completed）一并兼容。
const STAGE_STATUS_CN = {
  pending: '未开始', ongoing: '办理中', completed: '已完成',
  '进行中': '办理中', '未开始': '未开始', '已完成': '已完成',
}

function orgTypeFn(v) {
  if (v === 'village' || v === 'village_committee') return 'village_committee'
  if (v === 'community' || v === 'community_committee') return 'community_committee'
  return 'village_committee'
}

function candStatusCn(v, round) {
  if (v === 'approved') return '正式候选人'
  if (v === 'rejected') return '联审不通过'
  if (round === 'R2') return '待第2轮'
  if (round === 'R3') return '待第3轮'
  if (round === 'R4') return '待第4轮考察'
  return '待第1轮'
}

const FNS = { ts, day, s, offsetFrom, orgType: orgTypeFn, statusCn: (v) => STAGE_STATUS_CN[v] || s(v) || '未开始' }

/* ── 声明式映射 SCHEMA（from = 后端 API 蛇形字段名） ── */
const SCHEMA = {
  // GET /auth/organizations → [{id, slug, name, org_type, status}]
  organizations: [
    { to: 'id', from: 'id' }, { to: 'slug', from: 'slug' }, { to: 'name', from: 'name' },
    { to: 'town', const: '' }, { to: 'type', from: 'org_type', fallbackFrom: 'orgType', fn: 'orgType' },
    { to: 'status', from: 'status' },
    { to: 'org_phone', const: '' }, { to: 'org_person', const: '' }, { to: 'org_note', const: '' },
  ],
  // GET /candidate/elections → [{id, name, d_day, status, term_name}]
  elections: [
    { to: 'el_org_id', from: 'organization_id', fallbackCtx: 'orgId' },
    { to: 'el_id', from: 'id' },
    { to: 'el_term', from: 'term_name', fn: 's' },
    { to: 'el_name', from: 'name', fn: 's' },
    { to: 'el_status', from: 'status', fn: 's' },
    { to: 'el_election_date', from: 'd_day', fn: 'day' },
    { to: 'el_method', const: '全民直选' },
    { to: 'el_proposal_id', const: '' },
    { to: 'el_note', const: '' },
  ],
  // GET /candidate/announcements → [{id, title, body, status, published_at, stage_key, at_code}]
  announcements: [
    { to: 'ann_org_id', from: 'organization_id', fallbackCtx: 'orgId' },
    { to: 'ann_election_id', from: 'election_fief_id', fallbackCtx: 'electionId' },
    { to: 'ann_code', from: 'at_code', fn: 's' },
    { to: 'ann_title', from: 'title', fn: 's' },
    { to: 'ann_stage_key', from: 'stage_key', fn: 's' },
    { to: 'ann_status', from: 'status', fn: 's' },
    { to: 'ann_version', const: 1 },
    { to: 'ann_editor', const: '' },
    { to: 'ann_edit_time', const: '' },
    { to: 'ann_reviewer', const: '' },
    { to: 'ann_review_time', const: '' },
    { to: 'ann_publish_time', from: 'published_at', fn: 'ts' },
    { to: 'ann_publicity_deadline', const: '' },
    { to: 'ann_pin', const: false },
    { to: 'ann_type', const: '公告' },
    { to: 'ann_content', from: 'body', fn: 's' },
    { to: 'ann_files', const: [] },
    { to: 'ann_open_material_submit', const: true },
  ],
  // GET /candidate/positions → [{id, name, quota, status, application_start, application_end, material_review_start, material_review_end}]
  positions: [
    { to: 'pos_org_id', from: 'organization_id', fallbackCtx: 'orgId' },
    { to: 'pos_election_id', from: 'election_fief_id', fallbackCtx: 'electionId' },
    { to: 'pos_type', from: 'name', fn: 's' },
    { to: 'pos_quota', from: 'quota' },
    { to: 'pos_status', from: 'status', fn: 's' },
    { to: 'pos_desc', const: '' },
  ],
  // GET /candidate/materials → 我的材料（materials 行 + files 聚合）
  materials: [
    { to: 'mat_org_id', from: 'organization_id', fallbackCtx: 'orgId' },
    { to: 'mat_election_id', from: 'election_fief_id', fallbackCtx: 'electionId' },
    { to: 'mat_applicant_id', ctx: 'phone' },
    { to: 'mat_position_id', from: 'title', fn: 's' },
    { to: 'mat_type', from: 'title', fn: 's' },
    { to: 'mat_status', from: 'status', fn: 's' },
    { to: 'mat_submitter', ctx: 'phone' },
    { to: 'mat_stage', const: '' },
    { to: 'mat_submitter_phone', ctx: 'phone' },
    { to: 'mat_candidate_id', from: 'id' },
    { to: 'mat_submit_time', from: 'submitted_at', fn: 'ts' },
    { to: 'mat_review_time', from: 'reviewed_at', fn: 'ts' },
    { to: 'mat_reviewer', from: 'reviewed_by', fn: 's' },
    { to: 'mat_review_comment', from: 'review_note', fn: 's' },
  ],
  // GET /candidate/candidates → 候选人战况名单
  candidates: [
    { to: 'cand_org_id', from: 'organization_id', fallbackCtx: 'orgId' },
    { to: 'cand_election_id', from: 'election_fief_id', fallbackCtx: 'electionId' },
    { to: 'cand_acc_id', from: 'phone', fn: 's' },
    { to: 'cand_name', from: 'display_name', fallbackFrom: 'candName', fn: 's' },
    { to: 'cand_position_id', const: '委员' },
    { to: 'cand_source', const: 'self' },
    { to: 'cand_gender', const: '' },
    { to: 'cand_age', const: '' },
    { to: 'cand_phone', from: 'phone', fallbackFrom: 'candPhone', fn: 's' },
    { to: 'cand_status', from: 'status' },
    { to: 'cand_note', const: '' },
  ],
  // roster（花名册）表
  roster: [
    { to: 'ros_org_id', const: '' }, { to: 'ros_position', const: '' },
    { to: 'ros_name', const: '' }, { to: 'ros_phone', const: '' },
    { to: 'ros_term', const: '' }, { to: 'ros_year_start', const: '' },
    { to: 'ros_year_end', const: '' }, { to: 'ros_status', const: '' },
    { to: 'ros_is_active', const: '' }, { to: 'ros_session_no', const: '' },
    { to: 'ros_note', const: '' },
  ],
}

// 自定义批量字段（无法纯声明式表达的批量/结构转换）
const BUILDERS = {
  // candidates 四轮审核：兼容后端 reviews 数组与平铺字段
  candidatesRound: (r) => {
    const out = {}
    const reviews = Array.isArray(r.reviews) ? r.reviews : []
    for (const k of ['r1', 'r2', 'r3', 'r4']) {
      const match = reviews.find(rv => rv.round && rv.round.toLowerCase() === k)
      if (match) {
        out['cand_' + k] = match.decision === 'approved' ? '通过' : '不通过'
        out['cand_' + k + '_time'] = ts(match.created_at || match.time)
        out['cand_' + k + '_reviewer'] = s(match.reviewer_name || match.reviewer || '选委会')
        out['cand_' + k + '_comment'] = s(match.note || match.comment)
      } else {
        const C = 'cand' + k.toUpperCase()
        out['cand_' + k] = r[C] ? s(r[C]) : '待审'
        out['cand_' + k + '_time'] = ts(r[C + 'Time'])
        out['cand_' + k + '_reviewer'] = s(r[C + 'Reviewer'])
        out['cand_' + k + '_comment'] = s(r[C + 'Comment'])
      }
    }
    // 状态转中文
    out.cand_status = candStatusCn(r.status, r.current_round)
    return out
  },
}

/* ── 通用驱动 ── */
function applyRule(rule, row, ctx) {
  if (rule.const !== undefined) return rule.const
  let v = row[rule.from]
  if ((v === null || v === undefined || v === '') && rule.fallbackFrom) v = row[rule.fallbackFrom]
  if ((v === null || v === undefined || v === '') && rule.fallbackCtx && ctx) v = ctx[rule.fallbackCtx]
  if ((v === null || v === undefined || v === '') && rule.ctx && ctx) v = ctx[rule.ctx]
  if (rule.fn && FNS[rule.fn]) v = FNS[rule.fn](v)
  return v === undefined ? (rule.def !== undefined ? rule.def : '') : v
}

function projectRow(table, row, ctx) {
  const defs = SCHEMA[table]
  if (!defs) return row
  const out = {}
  for (const rule of defs) out[rule.to] = applyRule(rule, row, ctx)
  if (table === 'candidates') Object.assign(out, BUILDERS.candidatesRound(row))
  if (table === 'materials') {
    // 附件：后端 files 字段聚合（兼容 {fileName, storageKey} 与 {name, url}）
    const files = Array.isArray(row.files) ? row.files : []
    out.mat_attachments = files.map((x) => ({
      name: x.file_name || x.fileName || x.name || '附件',
      url: x.storage_key || x.storageKey || x.url || ''
    }))
  }
  return out
}

function projectRows(table, rows, ctx) {
  return (rows || []).map((r) => projectRow(table, r, ctx))
}

/* ── 导出（签名保持，http.js / cloud.js 零改动） ── */
function mapOrgs(rows) { return projectRows('organizations', rows) }
function mapElections(rows) { return projectRows('elections', rows) }
function mapAnnouncements(rows) { return projectRows('announcements', rows) }
function mapPositions(rows) { return projectRows('positions', rows) }
function mapCandidates(rows) { return projectRows('candidates', rows) }
function mapMaterials(rows, ctx) { return projectRows('materials', rows, ctx) }

/** GET /candidate/elections/:id/stages → election_stages
 *  后端返回蛇形数组：stage_key/stage_name/start_date/end_date/stage_order/status；
 *  D 日由调用方从 elections 取到后以 dDay 传入，偏移量 = 真实日期相对 D 日的天数差。 */
function mapStages(rows, dDay, orgId, elId) {
  return (rows || []).map((x) => ({
    es_org_id: s(orgId),
    es_election_id: s(elId),
    es_stage_key: s(x.stage_key),
    es_stage_name: s(x.stage_name),
    es_offset_start: offsetFrom(dDay, day(x.start_date)),
    es_offset_end: offsetFrom(dDay, day(x.end_date)),
    es_status: FNS.statusCn(x.status),
    es_biz_module: '',
    es_note: '', // 后端阶段接口未返回说明字段，如实置空（不造假）
  }))
}

module.exports = {
  ts, day, offsetFrom, SCHEMA, projectRow, projectRows,
  mapOrgs, mapElections, mapStages, mapAnnouncements, mapPositions,
  mapCandidates, mapMaterials,
}
