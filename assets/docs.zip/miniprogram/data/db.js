// 本文件由 scripts/gen_mini_db.py 自动生成（数据源=scripts/data/，与xlsx/CSV/Vue前端完全同源）
// 请勿手改；改数据请改 scripts/data/ 后重新生成
//
// ⚠️ 2026-09 村居换届选举系统对接 backend-new（3100）重构：
//   演示种子数据已全部清空（铁律：不要假数据，空态如实显示空态）。
//   所有业务表改为空数组 []，结构与键名保持不变，页面 require('../../data/db').DB 零改动即可工作；
//   登录后由 data/http.js 的 syncAll 从 backend-new 拉取真实数据原位覆盖。
//   红线 A-002：选举结果（投票）表整表删除，无对应后端接口，亦不展示投票结果。
const SNAPSHOT_DATE = '2026-07-21'  // 演示快照日：涧口=D-9联审首日；延寿=D+5（离线兜底用，在线时由 /health.today 覆盖）

const DB = {
 "organizations": [],
 "elections": [],
 "election_stages": [],
 "stage_templates": [],
 "announcement_templates": [],
 "roles": [],
 "role_quotas": [],
 "accounts": [],
 "account_roles": [],
 "positions": [],
 "proposals": [],
 "materials": [],
 "candidates": [],
 "announcements": [],
 "notifications": [],
 "notification_reads": [],
 "roster": [],
 "archives": [],
 "design_notes": [],
 "project_memory": []
}

// ── 组织选择辅助 ──
function findOrg(slugOrId) {
  return DB.organizations.find(o => o.slug === slugOrId || o.id === slugOrId)
}
function findElection(elId) { return DB.elections.find(e => e.el_id === elId) }
function orgElections(slugOrId) {
  return DB.elections.filter(e => e.el_org_id === slugOrId || !e.el_org_id)
}
function scopedOf(orgSlugOrId, elId) {
  const org = findOrg(orgSlugOrId)
  const matchOrg = (r, keys) => {
    if (!orgSlugOrId) return true
    return keys.some(k => {
      const val = r[k]
      return !val || val === orgSlugOrId || (org && (val === org.id || val === org.slug))
    })
  }
  const matchElection = (r, key) => {
    if (!elId) return true
    const val = r[key]
    return !val || val === elId
  }

  return {
    stages: DB.election_stages.filter(s => matchElection(s, 'es_election_id')),
    materials: DB.materials.filter(m => matchOrg(m, ['mat_org_id']) && matchElection(m, 'mat_election_id')),
    candidates: DB.candidates.filter(c => matchOrg(c, ['cand_org_id']) && matchElection(c, 'cand_election_id')),
    announcements: DB.announcements.filter(a => matchOrg(a, ['ann_org_id']) && matchElection(a, 'ann_election_id')),
    notifications: DB.notifications.filter(n => matchOrg(n, ['notif_org_id'])),
    // 红线 A-002：选举结果整表已删除，无后端接口，如实返回空
    results: [],
    roster: DB.roster.filter(r => matchOrg(r, ['ros_org_id'])),
    // positions 必须进作用域：material 页岗位按钮读 s.positions。
    positions: DB.positions.filter(p => matchOrg(p, ['pos_org_id']) && matchElection(p, 'pos_election_id'))
  }
}

// ============ 选举方式真相源（手动维护，来源：①村居换届倒排工期表·公告正文模板.docx ②设计稿 选举系统_填空模板.html 归属地弹窗） ============
// 结论（与设计稿弹窗 divergeInfo/typeDetailCard 完全一致）：
//  - 村委会(org.type=village_committee)：主任/副主任/委员 统一由本村登记选民直接投票（全民直选）产生，唯一模式不可更改。
//  - 居委会(org.type=community_committee)：由居民代表会议表决选举办法，从 全民直选/户代表选举/居民代表选举 三选一。
// 说明：
//  1) el_method 字段只记录「本届实际选用的方式」，并不穷举可选方式。
//  2) 「支持哪些选举形式」由 org.type 决定——即登录时选择归属地(村/居)已埋点筛选，
//     因此本清单应基于当前 org.type 取用，而非写死。
//  3) 差额/等额 是「确定正式候选人」的预选规则（按应选名额差额数），不是职位的最终选举形式，勿混淆。
// 注意：本段为手工录入的真相源，db.js 若被 scripts/gen_mini_db.py 重新生成需手动回填。
const ELECTION_METHOD_CATALOG = {
  village_committee: [
    { key: '全民直选', desc: '由本村登记选民直接投票选举产生（唯一合法方式，不可更改）。' }
  ],
  community_committee: [
    { key: '全民直选', desc: '由本社区登记居民直接投票选举产生。' },
    { key: '户代表选举', desc: '以户为单位推选户代表，由户代表会议投票选举产生。' },
    { key: '居民代表选举', desc: '由居民代表会议投票选举产生。' }
  ]
}
function electionMethodsByOrgType(orgType) {
  return ELECTION_METHOD_CATALOG[orgType] || ELECTION_METHOD_CATALOG.village_committee
}

// ============ 候选人四轮审核轮次标签真相源（手动维护，来源：同上 docx + stage_templates.st_review_round） ============
// 口径随 org.type（登录归属地已埋点）：村=镇级初审/党委考察；居=街道初审/党工委考察。
// 对应阶段：r2↔D-13，r3+r4↔D-9~-5。与 ELECTION_METHOD_CATALOG 同为手工区，重生成 db.js 需回填。
const REVIEW_ROUND_CATALOG = {
  village_committee: [
    { key: 'r1', label: '第一轮 · 材料完整性审核' },
    { key: 'r2', label: '第二轮 · 镇级资格初审' },
    { key: 'r3', label: '第三轮 · 区级11部门联审' },
    { key: 'r4', label: '第四轮 · 党委考察' }
  ],
  community_committee: [
    { key: 'r1', label: '第一轮 · 材料完整性审核' },
    { key: 'r2', label: '第二轮 · 街道资格初审' },
    { key: 'r3', label: '第三轮 · 区级多部门联审' },
    { key: 'r4', label: '第四轮 · 党工委考察' }
  ]
}
function reviewRoundsByOrgType(orgType) {
  return REVIEW_ROUND_CATALOG[orgType] || REVIEW_ROUND_CATALOG.village_committee
}

module.exports = { DB, SNAPSHOT_DATE, findOrg, findElection, orgElections, scopedOf, ELECTION_METHOD_CATALOG, electionMethodsByOrgType, REVIEW_ROUND_CATALOG, reviewRoundsByOrgType }
