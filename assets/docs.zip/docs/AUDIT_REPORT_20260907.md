# 村居换届选举系统后端代码审核报告

**审核时间**：2026-09-07  
**审核范围**：backend-new 全部路由 + schema.sql + rebuild-db.mjs + seed-templates.mjs  
**审核基准**：甲方官方 DOCX《村居换届倒排工期表【新增业务操作阶段映射列 公告正文模板】》  
**审核方式**：静态代码取证（证据副本，未改动正式工作区或线上）

---

## 核心结论

**项目属"版本混入+半成品合并"坏状态**

- **新版代码**（已入库）：`proposals.ts` / `announcements.ts` / 前端 Notice 模块 / `seed-templates.mjs` = D 日倒排 + 自动排期公告 + 岗位样表附件
- **旧版 schema**（权威）：`schema.sql` + `rebuild-db.mjs`（唯一建库脚本）停留旧版
- **迁移缺失**：无任何迁移补列对齐新旧版本

→ 按规范从零建库（`rebuild-db.mjs` 全执行）后，提案审批主链路必 500 回滚，所有下游（活动/日程/岗位/公告/归档）全部不产生

---

## P0 —— 直接锁死主链路（提交不了提案/归档没同步创建）

| # | 问题 | 证据 |
|---|------|------|
| **1** | **权限点 `proposal:create` 不存在** → 所有人（含超管）创建/编辑提案全 403 | **代码**：`proposals.ts:9/55` 用 `requirePerm('proposal:create')`<br>**种子**：`rebuild-db.mjs:64-66` 权限宇宙只有 `proposal:edit/review`<br>`ALL_PERMS`（platform_admin/sub_admin）也无此权限 |
| **2** | 审批"通过"写 `positions` 不存在的列 → 500 回滚 | **代码**：`proposals.ts:112-114` INSERT `election_method`, `requirement`<br>**权威 DDL**：`schema.sql:191-201` positions 表无这两列 |
| **3** | 同一事务写 `announcements` 三个不存在的列 → 500 | **代码**：`proposals.ts:175-176` INSERT `template_id`, `scheduled_for`, `stage_key`<br>**权威 DDL**：`schema.sql:234-252` announcements 表无这三列<br>**迁移**：`migrations/20260905_announcement_workbench_cols.sql` 只补了 `ann_sign` 等，**没补这三个** |
| **4** | 查 `announcement_templates.at_sched_offset` → 列不存在 → 500 | **代码**：`proposals.ts:141` 查询 `where at_sched_offset is not null`<br>**权威 DDL**：`schema.sql:144-160` announcement_templates 无此列<br>**rebuild-db**：无补列逻辑 |
| **5** | "驳回"写 `election_proposals.reject_reason` → 列不存在 → 500 | **代码**：`proposals.ts:96` UPDATE `set reject_reason=$4`<br>**权威 DDL**：`schema.sql:177-191` election_proposals 无此列 |

**配套脚本同病**：

- `seed-templates.mjs:53` 首行 `delete from announcements where template_id is not null` → `template_id` 列不存在 → 删除失败
- `seed-templates.mjs:57` 插入 `at_sched_offset` → 列不存在 → 插入失败
- → 新版"D 日倒排公告"从未真正入库，代码悬空

**根因锁链**：

提案审批通过/驳回两条路全崩（P0.2-5 任一列缺失即事务回滚）→ 活动/日程/岗位/公告/归档全不产生 → 对应用户反馈"提交不了新的提案""选举归档没有跟提案审批成功同步创建"

---

## P1 —— 功能缺失/版本不一致

| # | 问题 | 证据 |
|---|------|------|
| **6** | **候选人审核四轮无起止日期** | **代码**：`candidates.ts:2-3` 注释确认 R1~R4 四轮<br>`candidates.ts:52` 审核枚举 `['R1','R2','R3','R4']`<br>**列表接口**：`candidates.ts:13-15` 返回 `c.*` 与 `reviews` 聚合<br>**无日期**：grep `start_date\|end_date\|deadline` 全无结果 → 前端表头"初审/二审/联审/考察（起始～截止日期）"无数据源 |
| **7** | **无外部送审邮箱/下载候选人全卷接口** | **全局搜索**：`grep -rn "external\|mail\|email\|download.*candidate\|送审" backend-new/src/routes/` 无结果 |
| **8** | **两种建活动日程公式不一致**（版本混合铁证） | **提案审批**：`proposals.ts:107`<br>`end_date = addDays(d_day, offset + max(0,duration-1))`<br>**手动建活动**：`elections.ts:19`<br>`end_date = addDays(dDay, duration)`<br>→ 同一届下两种入口生成的阶段起止区间**不同** |
| **9** | **`/admin/archives` 实时聚合查询，非审批时落库** | **代码**：`elections.ts:137` 注册 `/admin/archives` 路由<br>处理器按需拼接 `announcements/materials/proposals/files`<br>**proposals 审批**：`proposals.ts:85-134` 通过分支无任何 `insert into archives` 语句<br>**语义错误**：`elections.ts:106` proposals 用 `organization_id as "elId"` → 前端按 elId 分组会把归档树画错（应是 election_fief_id） |
| **10** | **一人只能归属一个组织** | **schema.sql:32**：`memberships.user_id unique`<br>**rebuild-db.mjs:102**：`on conflict (user_id) do update`<br>→ 与"130+ 村/社区、同干部可在多归属地兼任子管理/经办/审核"实际需求冲突 |
| **11** | **多附件预览只显 1 个** | **后端**：`material_files` 支持多文件，列表返回 `files[]`<br>→ 前端渲染问题（取 `files[0]`），非后端 |

---

## P2 —— 口径/残留/部署

| # | 问题 | 证据 |
|---|------|------|
| **12** | 权限命名不统一 | 路由 `proposal:create` vs 种子 `proposal:edit` |
| **13** | 一次性脚本留在仓库含生产硬编码 | `rebuild-db.mjs` / `seed-templates.mjs` 在根目录<br>含 `13800000000`、统一密码、具体 d_day<br>误跑即污染线上 |
| **14** | 默认密码口径混乱 | 前端多处"初始密码默认 123456"<br>文档又写 `Admin@2026` |
| **15** | 社区公告替换过宽 | `proposals.ts:158` `/党委/g → 党工委` 全局替换<br>会污染其他含"党委"文本 |
| **16** | 端口/基址写死 | 小程序 `BASE_URL=http://127.0.0.1:3100`<br>未走环境变量 `DEPLOY_RUN_PORT` / `COZE_PROJECT_DOMAIN_DEFAULT` |

---

## 建议修复顺序

1. **补对齐迁移**（二选一，禁止两版本并存）：
   - **方案 A**：给 `positions`(+election_method/requirement)、`announcement_templates`(+at_sched_offset)、`announcements`(+template_id/scheduled_for/stage_key)、`election_proposals`(+reject_reason) 加列
   - **方案 B**：降级新版路由回 schema
2. **统一权限点**：`proposal:create` 并入种子授权（或改路由用 `proposal:edit`），给超管补上
3. **按 DOCX 固化审核日程** + 外送(邮箱)/下载候选人全卷接口
4. **统一两处日程公式**；`/admin/archives` 改为审批通过时生成归档快照记录
5. **清理重构** `rebuild-db.mjs` / `seed-templates.mjs` 等一次性脚本与生产硬编码

---

## 审核范围说明

**已核对一致**（未列入问题）：`materials`、`material_files`、`candidate_reviews`、`candidates`、`election_fief_stages` 表 DDL 与代码匹配

**审核方式**：静态代码取证，**未改动任何正式项目代码或线上**

---

**审核人**：阿圆  
**交付时间**：2026-09-07
