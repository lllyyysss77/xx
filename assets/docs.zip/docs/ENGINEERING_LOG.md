# 工程工作日志 (ENGINEERING_LOG.md)

### [2026-09-08 交付单元] 数据库上云 + 双版本比对 + 文档同步

- **背景**：
  接手时发现数据库已从本地迁移到 Supabase 云端，但核心文档均未更新；同时存在 `backend-new/` 和 `projects/` 两个后端版本，功能差异不明。需要确认哪版可启动、差异在哪、哪些 P1 已修复。

- **核心思路**：
  三方交叉验证（主 agent + 2 个独立子 agent）对比两个后端版本的代码差异与数据库 schema 差异，确认真实运行状态。同步更新所有核心文档到当前真实状态，消除文档与代码脱节。

- **具体执行步骤**：
  1. X-RAY 重新扫描全项目，确认目录结构与运行端口
  2. 双后端启动验证：`backend-new/`（连云端）和 `projects/`（连本地）均健康检查通过
  3. 代码层差异审查：7 个路由文件 + lib.ts 有差异，projects 多 1 个 migrate-file.ts
  4. 数据库层差异审查：多 6 个业务列 + 1 个复合唯一约束 + 2 个 migration
  5. 三方结论交叉验证，完全一致
  6. 安装 token 效率三件套（Ponytail + Caveman）
  7. 小史官打捞珍珠 + 人工低压 compact
  8. 同步更新 PROJECT_STATE.md

- **代码变更文件清单**：
  - 修改：`docs/PROJECT_STATE.md`（同步当前真实状态）
  - 新增：`projects/.env`（复制自 backend-new 本地库配置）
  - 新增：`projects/node_modules/`（依赖安装）

- **发现和确认**：
  1. 数据库已上云 Supabase，`backend-new/.env` 为云端连接串
  2. `projects/` 是更新版本，P1 修复已覆盖大半（审核日期/外部送审/多归属地）
  3. 交付清单.md、README-部署说明.md 等文档仍写本地数据库，已过时
  4. 前端 node_modules 未安装，5173 无响应
  5. 本地库密码不是 123456（哈希不匹配），需 rebuild-db 重置

- **验证结果**：
  - 后端健康检查：3100/3101/3102 均返回 `{"ok":true,"db":"up"}`
  - 代码差异：三方独立审查结论完全一致
  - migration：projects 版 3 个迁移全部应用成功

- **接力棒说明**：
  下一步：1) 决定是否合并 projects/ 回主版本；2) 装前端依赖；3) 全链路冒烟测试。

---

### [2026-09-07 交付单元] 投毒深度清理与文档同步更新

- **背景**：
  第一轮清理（seed-demo.ts / seed-candidates.ts / 前端双读代码）后，发现仍有大量残留脏文件和误导性代码。数据库中 124 个脏组织、飞书历史脏数据、6 个含硬编码密码的调试脚本、批量重置密码危险脚本、根目录 8 个废弃脚本、以及文档中大量"演示村/演示社区"过时信息。

- **核心思路**：
  两轮式深度清理：第一轮清显性投毒（假数据种子 + 前端双读），第二轮通过代码审计全面扫描，清除隐性脏数据（调试脚本、历史一次性脚本、兼容路由、注释示例中的演示字样、文档过时信息）。同步更新所有核心文档，确保文档与代码状态 100% 一致。

- **具体执行步骤**：
  1. 全面审计扫描：遍历 `backend-new/src/` 和 `web/src/`，识别 10 大类问题。
  2. 第二轮文件清理：删除 10 个脏文件（飞书导入脚本、历史脏数据 JSON、6 个调试脚本、重置密码脚本）。
  3. 第二轮代码清理：删除 `/api/archives` 旧路径兼容路由，修改 3 处"演示村/演示社区"注释示例。
  4. 根目录清理：将 8 个 `_` 开头的历史一次性脚本移至 `_removed_legacy/` 归档。
  5. 文档同步更新：更新 HANDOFF、CONNECTIONS、PROJECT_STATE、项目实时架构模块图、14号系统认知基线、30号全景施工图纸 共 6 份核心文档。

- **代码变更文件清单**：
  - 删除：`backend-new/src/import-feishu.py`、`import-feishu-runner.mjs`、`feishu_clean_data.json`
  - 删除：`backend-new/src/check-pwd.ts`、`check-db.ts`、`check-cr.ts`、`check-constraint.ts`、`check-cols.ts`、`check-biz.ts`
  - 删除：`backend-new/src/reset-pwd.ts`
  - 修改：`backend-new/src/routes/elections.ts`（删除 `/api/archives` 兼容路由）
  - 修改：`web/src/modules/proposals/Proposals.tsx`（"演示村"→"本村"）
  - 修改：`web/src/utils/pipelineEngine.ts`、`web/src/components/ElectionSessionList/SessionDetailBar.tsx`（注释示例更新）
  - 归档：根目录 8 个 `_` 开头废弃脚本 → `_removed_legacy/`
  - 文档：`HANDOFF_20260907.md`、`CONNECTIONS.md`、`PROJECT_STATE.md`、`项目实时架构模块图.md`
  - 取证文档：`14_系统认知基线-脱稿制.md`、`30_村居换届选举系统_全景施工图纸与模块架构全书.md`

- **验证结果**：
  - 前端 `npx tsc --noEmit` 0 错误
  - 后端健康检查 `GET /health` 返回 db:up
  - 最终核验：前端 0 个演示/假数据关键词，后端 0 个调试脚本和脏数据生成脚本

- **接力棒说明**：
  代码和文档已同步至最新状态。后续开发以 `3_案件取证/` 目录下权威文档为准，测试账号见 `CONNECTIONS.md` 第 4 节。

---

### [2026-09-05 交付单元] Web前端全量模块重构与施工图纸终极落盘

- **背景**：
  原交付前端充斥大量 Mock.js、假 Store、未映射的 `/api/*` 404 路径及概念污染，急需按照甲方 DOCX 法律 SOP 及本机真实 PostgreSQL `backend_new` 库进行 1:1 模块化、插件化全量重写，并输出零前情提要即可开工的施工图纸。
- **核心思路**：
  以 D-day 倒排 Pipeline 为核心定盘星，彻底实现农村行政村（`village`）与城市社区（`community`）的物理双轨隔离。全面废除 Redux 与假 Store，基于 Zustand 构建持久化状态流，开发通用的 `PermGate`、`FileList`、`SopTimeline`、`LegalDocViewer` 等高阶复用组件，全量覆盖 15 个页面模块。
- **具体执行步骤**：
  1. 合并归一分散资料，清理过期碎片，封存 23 号皇榜。
  2. 搭建全新的 API 数据层（自动递归 `toCamelCase` 拦截转换），对齐 Fastify 后端 11 个真实路由模块。
  3. 逐页重写并压实 15 个核心业务页面（登录、提案、活动、公文台、设岗表、材料、候选人、归档树、用户、角色等）。
  4. 排查并修复后端 2 个潜藏盲区：兼容小程序老路径 `/api/login`；补齐小程序参选人围观战况的 `GET /candidate/candidates` 接口。
  5. 编制全景施工图纸（`30_全景施工图纸与模块架构全书.md`）与《项目实时架构模块图.md》。
- **代码变更文件清单**：
  - 前端 API 层：`web/src/api/*.ts` (13 个接口文件)
  - 核心 Store 与组件：`web/src/stores/*.ts`, `web/src/components/*`
  - 核心业务页面：`web/src/modules/*` (15 个业务页面)
  - 插件注册与路由：`web/src/plugins/*`, `web/src/router/*`
  - 后端修复补齐：`backend-new/src/routes/auth.ts`, `backend-new/src/routes/candidates.ts`, `backend-new/src/routes/proposals.ts`
  - 施工图纸与字典：`3_案件取证/29_全量页面组件与数据库双向映射全景字典.md`, `3_案件取证/30_村居换届选举系统_全景施工图纸与模块架构全书.md`, `项目实时架构模块图.md`
- **验证结果**：
  - 执行 `npx tsc --noEmit`，TypeScript 静态类型检查 0 报错通过。
  - 执行 `npm run build`，生产环境打包成功构建输出至 `dist/`。
- **接力棒说明**：
  系统已完全具备脱稿独立施工与部署条件，任何新工程师或 Agent 查阅《30号施工图纸》即可开箱即用。
