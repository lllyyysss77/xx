# Web 后台 UI 改造方案（v3 定稿 · 已过交叉审核）

> 项目：K:\3\3\纯净交付包（村居换届选举系统）
> 状态：**定稿**。已由独立 sub-agent 交叉审核（结论：有条件通过，7 项修正全部吸收）。代码在线上用，实施按「先低风险展示层 → 后上传组件」两期推进，每期构建验证。
> 审核基准：2026-09-08，后端健康检查 `db:up`。全程只读验证（源码 + 只读 SQL），未改代码/数据。

---

## 〇、需求清单（用户原话）

1. 「ui后台上每个页面有届次，这个东西不要单独列」→ 删届次独立列
2. 「筛选器用关键词，和日期区间就好」→ 筛选器简化
3. 「材料预览点击就出现这个，报错」（GET /files/test-key-001 400）→ 修预览报错
4. 「上传的东西好像都不能预览」→ 上传后可预览
5. 用 TDesign 官方 Upload 组件（requestMethod + formatResponse + onPreview）
6. 「活动列表-点击进去的明细页面，列表api调用和数据有问题」→ 明细页阶段/公告匹配修复
7. 「右侧的小编工作台不会随着下拉，会变成左半边下拉很下，右边还在顶部」→ 两栏滚动修复

---

## 一、问题根因（均已实证）

### P1. 材料预览点击 400
`material_files` 表 1 条脏数据：`storage_key='test-key-001'`（id=`76076536-6d09-43a4-9fea-7aa3798a6103`，file_name=`张三自荐表.jpg`），不满足后端 key 正则且磁盘无文件。前端无非法 key 防御。

### P2. 上传后不能预览
`FileList.tsx:28` 仅对 `image/*` 显示预览；PDF/Word/Excel 无预览入口。上传链路 6 处（见 M3）。

### P3. 届次列占位
`ElectionSessionList/index.tsx:33-38`（含 width:140 + cell 渲染 `row.termName || sessionNo(row.name)`）+ `Activities.tsx:67`。`termName` 恒空（后端无 JOIN）→ 届次列整列空白、届次筛选器恒空且选中即清空列表。

### P4. 筛选器冗余
`Activities.tsx:193-236` 三个 Select（届次/年份/状态），届次是坏的空下拉。

### P5. 明细页阶段/公告匹配断裂
- 库 `stage_templates` 16 阶段 vs 前端 `docxRules.ts` 14 阶段；7 处阶段名不一致 + 缺 2 阶段 → `docxRuleMap[currentStage.stageName]` 大多 undefined → 工作台显示「无需发文」、公告列表空。
- `parseNoticeNos` 正则 `/第(\d+)号/g` 提取缺陷：`第6-1号`→只出`6`（6-1 丢失）、`第10~15号全套配套公告`→空（6 个公告全丢）、`持续张贴 3 号公告`→空。
- 公告模板侧 OK：库 `at_code` 共 19 个（第1~17号/补充/第6-1号）。

### P6. 两栏滚动不同步
`.mainGrid { align-items:start }` 右栏未吸顶；且 **`Page.module.less:4` `.panel{overflow:auto}` 无高度约束** → 是 sticky 的最近滚动祖先但不滚动 → **position:sticky 完全失效**（审核实证的致命点）。

---

## 二、修改方案（M1~M7，已吸收全部审核修正）

### M1. `ElectionSessionList/index.tsx` 去掉届次列
- 删除列对象（33-38 行，含 width/cell 整块）。
- **仅删 `index.tsx:6` 的 `import { sessionNo }`**；**保留** `SessionDetailBar.tsx:8` 的 export（其自身 26 行仍调用 `sessionNo(fief.name)`）。
- 影响：材料/岗位/候选人/公告 4 页第一级列表同步少一列。

### M2. `Activities.tsx` 去届次列 + 筛选器改造
- 删 `{ colKey:'termName', title:'换届届次', width:140 }`（67 行）。
- 筛选条（193-236 行）：删届次 Select（termFilter/termOptions）+ 删年份 Select（yearFilter/yearOptions）；新增关键词 Input（搜 name；organizationName 是死代码——后端无此列，不再支持）+ 日期区间 DatePicker（按 dDay 字典序比较，`YYYY-MM-DD` 字符串可直接比较）；保留状态 Select + 重置 + 计数。
- 更新 filteredList useMemo（128-137 行）依赖。

### M3. 上传/预览改造（分两期）
**第一期（零上传风险，纯展示层）**：
- `FileList.tsx`：`FileItem` 的 `url/status` 设为**可选** + 内部兜底 `url || getFileUrl(storageKey)`；增加非图片预览（PDF `window.open`，Word/Excel 下载）；**非法 key 灰态防御**（不满足 `^[a-f0-9]{32}(\.[a-zA-Z0-9]{1,10})?$` 则不渲染入口，显示「文件缺失」）。
- `ActivityDetail.tsx:540`、`Archives.tsx:151-160`（审核补漏）：下载/预览入口加非法 key 防御。

**第二期（上传组件替换）**：
- **上传链路修正（审核高风险项）**：6 个上传点分两种链路，**禁止统一改成 `/files/upload` 两步走**：
  | 文件:行 | 链路 | 做法 |
  |---|---|---|
  | Materials.tsx:453,536 | 两步走（/files/upload → JSON 关联） | requestMethod 包装现有 API 函数 |
  | Proposals.tsx:525 | 两步走（内嵌提交） | 同上 |
  | Positions.tsx:274 | **直传 multipart 到业务端点**（无独立关联端点） | requestMethod 包装 `uploadPositionFile`（走 axios 直传） |
  | ActivityDetail.tsx:520 | **直传 multipart 到 `/admin/announcements/:id/file`** | 包装 `uploadAnnouncementFile` |
  | Proposals.tsx:551 | **直传 multipart 到 `/admin/proposals/:id/file`** | 包装 `uploadProposalFile` |
- **Authorization（审核修正）**：`headers` prop 对 `requestMethod` 路径**不生效**（useUpload.js:333-334 绕过内置 XHR）；方案 A：requestMethod 内手动 `xhr.setRequestHeader('Authorization','Bearer '+localStorage.getItem('cxq_token'))`；方案 B（推荐）：改用 `action={API_BASE_URL+'/files/upload'}` + `headers={{Authorization:'Bearer '+token}}` + `formatResponse`（内置 XHR 自动带 header）。**实施时统一方案 B**，无法 action 的直传端点用方案 A 包装现有 API 函数。
- `formatResponse` 映射：后端 `/files/upload` 返回 camelCase `{storageKey,fileName,mimeType,sizeBytes,relPath}`（lib.ts:148,169）→ 映射为 `{name,url,status,raw}`，`url=getFileUrl(storageKey)`。**确认无风险**。
- `Proposals.tsx` 岗位样表：设 `autoUpload={false}`，提交时手动触发（防取消表单产生孤儿文件）。
- `getFileUrl` 的 `?token=`：后端 `/files/:key` 无 auth，token 被忽略但暴露地址栏；M3 不处理（低风险，另排）。

### M4. 数据库脏数据处置
- **安全删除语句（审核修正：双保险）**：
  ```sql
  DELETE FROM material_files
  WHERE storage_key='test-key-001'
    AND id='76076536-6d09-43a4-9fea-7aa3798a6103'
    AND file_name='张三自荐表.jpg';
  ```
- 删除前先 SELECT 该行备份为 JSON（写入 `docs/` 备份）。
- 注意：`material_id` 对应 `materials` 表合法记录（title="主任"），**只删附件，不动材料**；删除后前端需正常展示「材料无附件」空态（M3 第一期覆盖）。
- 删除后 `material_files` 表为空（全表仅此 1 行）——确认业务可接受（该材料本无真实附件）。

### M5. 清理临时诊断脚本
- 删除 `backend-new/_diag_invalid_keys.cjs`、`backend-new/_diag_stage_match.cjs`。
- **审核补漏**：`backend-new/_backup_db.cjs`（有写文件副作用，产物在 `backups/` 2 个 json）→ 与用户确认后处置（建议：脚本删除或移入 scripts/，备份文件保留归档）。

### M6. 明细页阶段/公告匹配修复
- **`docxRules.ts`**：
  - 每个 `DocxStageItem` 增加 `stageKey` 字段（village 16 key：`prep/elect_committee/voter_reg/voter_list/voter_appeal/rep_election/nominate_start/nominate_cont/prelim_shortlist/primary_election/joint_review/formal_notice/campaign_prep/election_day/result_filing/handover`）。
  - 补齐 16 阶段（新增「村民代表和村民小组长选举」→ 公告第5/6/6-1号、「竞选预选」→ 无公告）；修正 7 处阶段名与公告号映射（对齐库 st_name + at_code）。
  - **COMMUNITY 派生修正（审核高风险项）**：`COMMUNITY_DOCX_STAGES = VILLAGE.map()` 仅覆盖第 3 阶段，**必须显式覆盖第 3/4/5 阶段的 stageKey**（`resident_reg/resident_list/resident_appeal`，而 village 是 `voter_reg/voter_list/voter_appeal`），否则社区 4-5 阶段匹配失败。
  - **字段名**：方案内文统一用 `announcementNums`（非 noticeNos，实际字段名 docxRules.ts:11）。
- **`ActivityDetail.tsx`**：
  - `docxRuleMap` 改为按 `stageKey` 索引（87-93 行）；`currentStageRule` 用 `stageKey`（137 行）；时间轴 `docxRuleMap[s.stageKey]`（344 行）。
  - **`parseNoticeNos` 修复（审核高风险项）**：支持三种写法——
    1. 子编号：`第6-1号` → 提取 `["6-1"]`（正则支持 `\d+-\d+`）
    2. 范围：`第10~15号全套配套公告` → 提取 `["10","11","12","13","14","15"]`
    3. 无第前缀：`持续张贴 3 号公告` → 提取 `["3"]`
    - 匹配侧正则同步：`^第?6-1号$` 需支持子编号（用精确模板编码列表匹配替代纯正则，更稳）。
  - 兜底：无规则阶段显示「本阶段无发文动作/线下组织推进」，不误提示「无需发文」。
- 影响：工作台 16 阶段全部匹配对应公告。纯前端，无接口变化。

### M7. 明细页两栏滚动修复
- **前置修复（审核实证的致命点）**：`.panel{overflow:auto}`（Page.module.less:4）无高度约束、自身不滚动，会拦截 sticky。**必须**先让 `.panel` 不再拦截：
  - 方案：`Page.module.less` `.panel` 的 `overflow:auto` → `overflow:visible`（全局一行 CSS）。已验证 `.sideContainer`（AppLayout.module.less:7-11, flex:1 + overflow:auto）才是真滚动容器；`.panel` 无高度约束，纵向滚动从未生效，改 visible 仅释放横向溢出行为，风险低。
  - 备选：仅 ActivityDetail 覆盖（CSS Modules 无法从子页覆盖父级 hash 类名，故采用全局一行）。
- **`ActivityDetail.module.less`**：
  - `.workCol { position: sticky; top: 16px; align-self: start; max-height: calc(100vh - 32px); overflow-y: auto; }`
  - `@media (max-width:1024px)` 单列布局：`.workCol { position: static; max-height: none; overflow: visible; }`
- 内容可达性：右栏 12 区块约 700-900px，1366×768 下 `overflow-y:auto` 保证内部滚动到发布按钮（审核：有条件通过）。

---

## 三、实施顺序与验证（两期）

**第一期（低风险，立即解决用户报障）**：M1 → M2 → M4（SQL 先备份后删）→ M6 → M7 → M3-第一期（FileList 预览防御 + 两处下载防御）。
- 每步 `cd web && npm run build`（或 tsc）验证；M7 用浏览器实测滚动行为。
**第二期（中风险，上传组件替换）**：M3-第二期 6 个上传点逐页替换，每页 build + 手动上传验证。
**M5**：随各期收尾清理。

---

## 四、明确不做
- 不改后端路由/表结构/接口契约（M4 数据清理除外）。
- 分页契约、字段名 F1/F3 等路由审计项——另行排期（F2 届次列空白已由 M1/M2 顺带解决）。
- 不改小程序端、不引入新依赖。
- 不动 `docxRules.ts` 文案/工作事项内容，仅补 stageKey/新增阶段/修正映射。

---

## 五、实施前置确认清单（给用户）
1. ✅ 审核已通过（有条件通过，7 项修正已吸收）——已确认
2. ❓ M4 数据删除：`material_files` 唯一 1 行脏数据删除，是否执行？（推荐执行）
3. ❓ M5 `_backup_db.cjs`：删除脚本 or 移入 scripts/？备份 json 保留？（推荐：删脚本，备份归档）
4. ✅ 实施顺序：第一期先上，验证后再第二期——待用户确认
