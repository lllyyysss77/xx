# Web 后台 UI 改造方案 v1 — 交叉审核报告（定稿）

> 审核时间：2026-09-08
> 审核方式：3 个子代理独立重读源码核实，Organizer 汇总冲突与共识
> 审核范围：方案 M1-M5 全部改动点 + 全量上传/预览点覆盖 + 技术可行性 + 风险评估 + 与路由审计结论交叉
> 审核原则：只读，未修改任何源码/数据，未执行任何 SQL

---

## 一、最终审核结论

### ⚠️ 需修订（列具体修订点）

方案大方向正确，用户需求理解准确，M1/M2/M4/M5 基本可实施。但 **M3（TDesign Upload 改造）存在 3 处必须修正的技术问题**，若按原方案实施会导致双重上传、缺失关联端点、非图片裂图等线上故障。修订后可通过。

**必须修正（3 项，阻塞实施）**：
1. M3 requestMethod 技术路线错误 → 改为直接调用现有业务 API 函数
2. M3 上传点遗漏 → 补充 Proposals.tsx:551（提案工作方案附件）
3. M3 theme="image" 不适用 → 改为 theme="file" + 自定义展示或 Upload 仅触发

**建议修订（7 项，不阻塞但影响质量）**：
4. M1/M2 行号修正 + organizationName 搜索死代码标注
5. M4 DELETE 按 id 精确删除 + 备份流程
6. M5 补充删除 `_diag_stage_match.cjs`
7. 风险表补充 8 项遗漏风险（20MB 限制、files:1、401 处理、回滚方案等）
8. A6 getFileUrl 拼 token 建议本次顺手修复（1 行改动）
9. Word/Excel 预览预期管理（只能下载，不能在线预览）
10. Proposals 延迟上传策略明确（autoUpload 冲突）

---

## 二、逐条审核

### M1：ElectionSessionList 去掉届次列

| 审核项 | 方案描述 | 审核意见 | 证据 |
|--------|---------|---------|------|
| 列行号 | `32-38 行` | **纠正**：实际 **33-38 行**（32 行是 `const columns = [` 数组声明） | `ElectionSessionList/index.tsx:33-38` |
| 列定义 | `{ colKey: 'session', title: '换届届次' }` | **确认+补充**：colKey 正确，但方案遗漏了 `width: 140` 和 `cell: ({row}) => <strong>{row.termName \|\| sessionNo(row.name)}</strong>` 兜底渲染 | `index.tsx:33-38` |
| sessionNo 导入 | 「同步删除 sessionNo 导入」 | **确认**：删 import 安全。但 **`sessionNo` 导出本身不能删**——`SessionDetailBar.tsx:26` 仍内部自用 | `index.tsx:6` import；`SessionDetailBar.tsx:8,26` |
| 共用页面 | 「材料/岗位/候选人/公告 4 个页面」 | **确认**：恰好 4 个，grep `ElectionSessionList` 无其他页面。Archives/Home/Dashboard/Proposals 均未使用 | Materials:41, Positions:20, Candidates:40, Announcements:19 |
| 副作用 | 「纯 UI，无接口变化」 | **确认**：删列后剩余列最低 780px（原 920px），name 列 minWidth 自动适配，无需手动调列宽。SessionDetailBar 不受影响 | `index.tsx:32-100` |

**M1 结论**：可实施，需修正行号和 sessionNo 安全提示。

---

### M2：Activities 去届次列 + 筛选器改造

| 审核项 | 方案描述 | 审核意见 | 证据 |
|--------|---------|---------|------|
| 届次列行号 | `Activities.tsx:67` | **确认**：行号、colKey、title、width 全部一致 | `Activities.tsx:67` |
| 筛选条行号 | `192-227 行` | **纠正**：实际 **192-236 行**，遗漏了重置按钮（228-232）和计数显示（233-235） | `Activities.tsx:192-236` |
| termName 恒空 | 「后端 select * 无 JOIN，termName 恒 undefined」 | **确认**：已实证到表结构层。`schema.sql:95-108` election_fiefs 表无 term_name 列；`elections.ts:29` 裸 select * 无 JOIN；client.ts 转换无法凭空生成列 | `schema.sql:95-108`, `elections.ts:29` |
| 关键词搜索 | 「匹配 name / organizationName」 | **纠正**：`organizationName` 恒为 undefined（同因），搜它是**死代码**。只能有效匹配 `name`。若需搜归属地需后端补 JOIN，超出本次范围 | `Activities.tsx:68`（organizationName 列也空白） |
| 日期区间用 dDay | 「按 dDay 区间过滤」 | **确认**：dDay 是法定选举日（非空、有倒计时逻辑、原年份筛选器已基于它），比 createdAt 更符合业务。方案选择正确 | `Activities.tsx:70-84,118-125` |
| 保留状态 Select | 「保留状态 Select」 | **确认**：选项 draft/active/closed 与前端类型、后端 CHECK 约束三方对齐 | `Activities.tsx:219-223`, `schema.sql:103` |
| filteredList 改动 | 「更新 useMemo 依赖与过滤逻辑」 | **确认+补充**：需联动改 5 处：①删 termFilter/yearFilter state ②新增 keyword/dateRange state ③删 termOptions/yearOptions useMemo ④重写 filteredList ⑤重写 resetFilters | `Activities.tsx:31-33,114-137,142-146` |
| 全页面届次列覆盖 | 方案列了 ElectionSessionList + Activities 两处 | **确认**：全项目 grep 仅 2 处，无遗漏。Archives 的 termName 是详情展示文本非列表列 | 全 `web/src` grep `colKey.*(届次\|term\|session)` |

**M2 结论**：可实施，需修正筛选条行号、标注 organizationName 搜索无效、穷举 5 处联动改动点。

---

### M3：上传/预览统一改用 TDesign Upload（核心风险区）

#### 3.1 上传点覆盖 — 实际 6 处，方案遗漏 1 处

| # | 文件:行号 | 场景 | 方案覆盖 | 现有上传模式 |
|---|-----------|------|----------|-------------|
| 1 | Materials.tsx:453 | 组织推荐附件（multiple） | ✅ | 两步走（uploadMaterialFile 内部先 /files/upload 再关联） |
| 2 | Materials.tsx:536 | 材料详情补传 | ✅ | 两步走（同上） |
| 3 | Positions.tsx:274 | 岗位样表上传 | ✅ | 直传 multipart（uploadPositionFile → /admin/positions/:id/file） |
| 4 | ActivityDetail.tsx:520 | 公告附件上传 | ✅ | 直传 multipart（uploadAnnouncementFile → /admin/announcements/:id/file） |
| 5 | Proposals.tsx:525 | 提案-逐岗位样表 | ⚠️ 描述模糊 | 延迟两步走（submit 时 uploadFile 拿 storageKey 嵌入 position） |
| 6 | **Proposals.tsx:551** | **提案-工作方案附件** | **❌ 遗漏** | 延迟直传（submit 时 uploadProposalFile → /admin/proposals/:id/file） |

**两个子代理独立确认**：全项目 `type="file"` 共 6 处，方案漏了 Proposals.tsx:551。

#### 3.2 【必须修正】requestMethod 技术路线错误

**方案原思路**：requestMethod → 统一调 `/files/upload` 拿 storageKey → 再调业务接口关联。

**问题**（3 个上传场景不兼容）：

1. **Materials 双重上传**：`uploadMaterialFile(materialId, file)` 内部第一步就是 `uploadFile(file)`（再次上传同一文件）。如果 requestMethod 已经上传过，再调 uploadMaterialFile 会导致**同一文件上传两次**，产生两个 storageKey，只有第二个被关联。
   - 证据：`api/materials.ts:81-89` — `uploadMaterialFile` 内部 `const { storageKey } = await uploadFile(file)` 然后 `request.post('/admin/materials/:id/file', { storageKey, ... })`

2. **Positions/Announcements/Proposals附件 无关联端点**：这三个场景的后端端点 `/admin/positions/:id/file` 等（`biz-files.ts:41-58`）只接受 multipart（文件本体），**不接受 JSON + storageKey**。如果先 `/files/upload` 拿 storageKey，再想关联到业务实体，**后端无对应端点**，必须改后端（与「后端零改动」矛盾）。

3. **Proposals 延迟上传冲突**：Proposals.tsx:525 和 :551 都是「选择后暂存、点击提交时才上传」，与 TDesign Upload 默认 `autoUpload=true`（选完即传）冲突。

**推荐修正路线**：requestMethod 内**直接调用现有业务 API 函数**，而非统一调 `/files/upload`：

```typescript
// 示例：Materials
const requestMethod = async (file: { raw: File }) => {
  try {
    const result = await uploadMaterialFile(materialId, file.raw);
    return { status: 'success', response: result };
  } catch (err) {
    return { status: 'fail', error: err.message };
  }
};
```

- 优势：完全复用现有 API 函数，axios 拦截器自动加 token（`client.ts:36-48`），无后端改动，无双重上传。
- 关键技术发现：使用 `requestMethod` 时，TDesign **完全不使用内部 XHR**（`useUpload.js:333` 分支），requestMethod 内可以用**任意 HTTP 客户端**包括 axios。方案中「axios 拦截器不会参与」的担忧**仅在使用 `action` prop 时成立**，使用 `requestMethod` 时不成立。
- requestMethod 入参是 `{ raw: File, name, size, type, ... }` 对象（非原生 File），需取 `file.raw`。

#### 3.3 【必须修正】theme="image" 不适用混合文件类型

**方案**：「图片（image/*）：theme='image' 组件内联预览」。

**问题**：所有 6 个上传点均接受**混合文件类型**（PDF/Word/Excel/图片）。例如 `Positions.tsx:290` 明确写「支持 PDF、Word、Excel 及图片格式」，`ActivityDetail.tsx:533` 写「支持 PDF / Word / 图片格式」。

如果对混合上传点使用 `theme="image"`，非图片文件的 `file.url` 会被 `<Image>` 加载，显示**裂图/空白卡片**。

**推荐修正**：
- 使用 `theme="file"` + 自定义 `fileListDisplay`，在自定义渲染中根据 `file.type` 区分图片（缩略图+点击放大）和非图片（文件图标+预览/下载按钮）。
- 或保留现有 `FileList` 组件做展示层，Upload 组件仅做上传触发（`autoUpload=true`，上传成功后回调更新 FileList 数据）。

#### 3.4 formatResponse 返回结构不准确

**方案**：「formatResponse 将后端元数据映射为 `{ name, url, status, raw }`」。

**纠正**：formatResponse 只需返回 `{ url: getFileUrl(storageKey), ...其他元数据 }`。`name/raw/status` 由组件内部 `formatToUploadFile` 在文件选中时就已设置，不需要 formatResponse 返回。
- 证据：`useUpload.js:340-344,364-365` — formatResponse 返回后，组件将 `response.url` 赋给 `file.url`，`file.response = response`。

#### 3.5 预览策略可行性

| 文件类型 | 预览方式 | 可行性 | 说明 |
|---------|---------|--------|------|
| 图片 | `<img>` 内联 + ImageViewer 放大 | ✅ 可行 | 需自定义 fileListDisplay（见 3.3） |
| PDF | `window.open(url)` 新标签页 | ✅ 可行 | 后端返回 `Content-Type: application/pdf`（`lib.ts:128-133`），浏览器内联预览 |
| Word/Excel | `window.open(url)` | ❌ 不可在线预览 | 浏览器无原生解析能力，触发下载。需第三方服务（Office Online/OnlyOffice/后端转PDF）才能在线预览，超出 M3 范围 |
| txt | `window.open(url)` | ✅ 可行 | 浏览器内联显示文本 |

**结论**：Word/Excel 在「后端零改动、不引入第三方服务」约束下只能做到「点击即下载」。方案应明确标注此限制，管理用户预期。

#### 3.6 非法 key 防御

**方案**：「storageKey 不满足正则时显示灰态」。

**确认**：正则 `^[a-f0-9]{32}(\.[a-zA-Z0-9]{1,10})?$` 与后端 `files.ts:84` 完全一致，覆盖 `.jpg`/`.pdf`/`.docx` 等带扩展名格式。前端当前无类似校验（FileList.tsx 直接对所有 key 渲染预览），新增是必要的。建议封装为公共函数 `isValidStorageKey(key)` 复用。

#### 3.7 后端 /files/upload 契约

**确认**：`POST /files/upload`（`files.ts:69-80`）使用 `@fastify/multipart`，FormData 字段名 `file`，需 `Authorization: Bearer`，返回 `{ storageKey, fileName, mimeType, sizeBytes, relPath }`。后端 `server.ts:27` 限制 `fileSize: 20MB, files: 1`。契约稳定，无需后端改动。

**M3 结论**：方向可行，但有 3 处必须修正的技术问题（requestMethod 路线、上传点遗漏、theme 不适用），修订后可实施。

---

### M4：数据库脏数据处置

| 审核项 | 方案描述 | 审核意见 | 证据 |
|--------|---------|---------|------|
| 脏数据根因 | `test-key-001` 不满足 32hex 正则、磁盘无文件、历史污染 | **确认**：`files.ts:84` 正则一致；`lib.ts:150` 正常上传生成 32hex+ext，test-key-001 不可能由上传接口生成；`lib.ts:127` 本地磁盘存储 `uploads/`，实际目录 8 个文件均为 32hex，无 test-key-001 | `files.ts:84`, `lib.ts:127,149-150` |
| 诊断脚本 | `_diag_invalid_keys.cjs` 查了 4 表，material_files 1 条非法 | **确认**：脚本查了 proposal_files/announcement_files/position_files/material_files 4 表，正则与后端一致，还额外查了空 key。结论可信，但实施 DELETE 前应重新运行确认当前状态 | `backend-new/_diag_invalid_keys.cjs:20-32` |
| 表结构 | material_files.storage_key | **确认+补充**：`text` 类型、**可空、无 CHECK、无 UNIQUE**。意味着同 key 可能有多条记录。外键方向是 `material_files → materials`（ON DELETE CASCADE 指删 materials 时级联删 material_files），反过来删 material_files 行**不影响** materials 表 | `schema.sql:173-176` |
| DELETE 方式 | `DELETE FROM material_files WHERE storage_key='test-key-001'`（或置空） | **纠正**：① 因 storage_key 无 UNIQUE，**推荐按 id 精确删除**：先 SELECT 拿 id，再 DELETE WHERE id。② **不推荐置空**——置空后变成「有文件名、无文件、无 key」的幽灵记录，FileList 仍显示文件名但点击无反应，体验更差。可逆性靠备份保障 | `schema.sql:175`（无 UNIQUE）, `FileList.tsx:34,45` |
| 备份流程 | 「实施前二次确认，保留 SQL 备份」 | **补充具体 SQL**：`CREATE TABLE material_files_del_backup_20260908 AS SELECT * FROM material_files WHERE storage_key='test-key-001'` → 确认行数 → 按 id DELETE → 验证 count=0。备份表保留 7 天 | — |

**M4 结论**：根因准确，DELETE 安全（外键方向无影响），但必须按 id 精确删除 + 先备份，不推荐置空。

---

### M5：清理临时诊断脚本

| 审核项 | 方案描述 | 审核意见 | 证据 |
|--------|---------|---------|------|
| 删除 `_diag_invalid_keys.cjs` | 方案已列 | **确认**：文件存在，34 行，只读诊断脚本，无源码引用 | `backend-new/_diag_invalid_keys.cjs` |
| 其他临时文件 | 方案仅列了 1 个 | **纠正：遗漏了 `_diag_stage_match.cjs`** | `backend-new/_diag_stage_match.cjs`（52 行，查 stage_templates/announcement_templates/election_fief_stages/announcements 匹配） |
| `_backup_db.cjs` | 方案未提及 | **建议保留**：41 行，全库 JSON 备份工具，是运维工具非临时诊断。建议保留或移至 `scripts/` 目录 | `backend-new/_backup_db.cjs` |

**M5 结论**：需补充删除 `_diag_stage_match.cjs`，`_backup_db.cjs` 建议保留。

---

## 三、风险表评估

### 原风险表（5 项）— 全部合理

| 风险 | 原等级 | 评估 |
|------|--------|------|
| 线上库 DELETE 脏数据 | 中 | 合理 |
| Upload 组件改造影响既有上传链路 | 中 | 合理（6 个上传点覆盖面广） |
| 多页面共改 | 中 | 合理 |
| 届次列删除影响业务认知 | 低 | 合理（届次信息保留在活动全称中） |
| 筛选器改坏 | 低 | 合理（纯前端过滤） |

### 遗漏风险（8 项，需补充）

| # | 风险 | 建议等级 | 说明 |
|---|------|----------|------|
| 1 | **后端 20MB 文件限制** | 中 | `server.ts:27` `fileSize: 20MB`，TDesign Upload 需配 `max` 前置校验，避免传到后端才被拒 |
| 2 | **后端 files:1 限制** | 中 | 每次请求仅接受 1 个文件，多文件必须**逐个上传**（循环逐个 POST），不能批量塞一个 FormData |
| 3 | **requestMethod 401 处理** | 中 | 虽用 axios 自动带 token，但 token 过期时上传返回 401，requestMethod 的 catch 应 `resolve({status:'fail'})` 并提示重新登录，不能静默失败 |
| 4 | **无回滚方案** | 中 | 应明确：前端回滚 = git revert + npm run build 重新部署；M4 回滚 = 从备份表 INSERT 恢复 |
| 5 | **测试覆盖不足** | 中 | build 通过 ≠ 功能正常。需 6 个上传点手动测试清单（上传→关联→展示→图片预览→PDF预览→非图片下载→非法key灰态→超20MB拦截） |
| 6 | **A6 token 泄露在 URL** | 中 | `getFileUrl` 拼 `?token=`，预览时 `window.open` 把 token 暴露在地址栏/历史/日志。M3 大量使用 getFileUrl，**建议本次顺手修复**（去掉 token 拼接，1 行改动，风险极低） |
| 7 | DELETE 后前端需刷新 | 低 | 无持久化缓存，刷新即可。若用户当前页面已加载含该记录的列表，需手动刷新 |
| 8 | 小程序端共用接口 | 低 | 小程序确实共用 `/files/upload` 和 `/files/:key`（`miniprogram/utils/api.js:85-117`），但本次仅改 Web 前端、后端契约不变，小程序无感。应在方案中明确说明 |

---

## 四、与路由审计结论的交叉验证

| 路由审计项 | 与本次改造关系 | 结论 |
|-----------|---------------|------|
| **F2** 届次/归属地列空白 | **直接相关** | 删 termName 列决策正确（该列恒空白，删了不影响信息展示）。删列后**无需修后端 SQL**——既然前端不展示了，后端加 JOIN 返回 termName 无意义。但 `Activities.tsx:68` 的 `organizationName`（归属村/社区）列**也空白**，方案 M2 只删了 termName 未提 organizationName。用户只要求删届次，所以保留 organizationName 列符合需求，但该列空白是 F2 的独立问题，应在方案中注明「organizationName 列空白为已知 F2 问题，本次不处理」 |
| **F3** 候选人手机号丢失 | **无交集** | Candidates.tsx 无上传/预览点，`getFileUrl`/`formatFileSize` 是死导入（`Candidates.tsx:39`）。F3 另行排期合理 |
| **A6** getFileUrl 拼无效 token | **直接相关** | M3 大量使用 getFileUrl 生成预览 URL。token 拼在 URL 中**不影响预览功能**（后端忽略），但是安全隐患。**强烈建议本次一并修复**——将 `getFileUrl` 改为仅 `${API_BASE_URL}/files/${encodeURIComponent(storageKey)}`，去掉 token 拼接。改动仅 1 处（`files.ts:20-23`），风险极低 |
| **分页契约** | **无交集** | 当前列表无分页参数传递，本次不涉及。另行排期合理 |
| **A1** HeaderIcon 越层 | **无交集** | 确认无关 |

---

## 五、方案一致性问题

1. **「后端零改动」表述不精确**（M3:89）：M4 是数据库 DELETE，应改为「**后端代码零改动**（路由/接口契约不变）；M4 为线上数据清理操作，非代码变更」。
2. **「4 个上传点」表述错误**：实际为 **4 个页面 6 个上传触发点**（Materials ×2、Proposals ×2）。
3. **M5 不完整**：遗漏 `_diag_stage_match.cjs`。
4. **A6 未纳入范围**：建议本次顺手修复 getFileUrl，或在「明确不做」中列出并说明理由。
5. **organizationName 列空白未提及**：M2 只删 termName，应注明 organizationName 列空白为已知 F2 问题、本次不处理。

---

## 六、修订后的方案要点（实施前需更新）

### M1（修订后）
- 删除 `ElectionSessionList/index.tsx:33-38` 的 session 列（含 width:140 和 cell 兜底渲染）
- 删除 `index.tsx:6` 的 `sessionNo` import（**勿删 SessionDetailBar.tsx 中的 sessionNo 导出，第 26 行仍内部自用**）
- 4 个共用页面（Materials/Positions/Candidates/Announcements）同步生效，无需逐页改
- 剩余列宽自动适配，无需手动调整

### M2（修订后）
- 删除 `Activities.tsx:67` 的 termName 列
- 筛选条（192-236 行）改造：删届次 Select + 年份 Select，新增关键词 Input + 日期区间 DatePicker，保留状态 Select + 重置按钮 + 计数
- **关键词仅匹配 `name`**（organizationName 后端无值，暂不匹配；如需搜归属地需后端补 JOIN，超出本次范围）
- 日期区间按 `dDay` 过滤（方案选择正确，dDay 比 createdAt 更符合选举业务）
- 联动改动 5 处：termFilter/yearFilter state → keyword/dateRange state；termOptions/yearOptions useMemo 删除；filteredList 重写；resetFilters 重写；筛选条 JSX 替换
- 注明：`Activities.tsx:68` 的 organizationName 列当前恒空白（已知 F2 问题），本次不处理

### M3（修订后 — 核心变更）
- **requestMethod 直接调用现有业务 API 函数**（uploadMaterialFile / uploadPositionFile / uploadAnnouncementFile / uploadProposalFile），**不统一调 /files/upload**。axios 拦截器自动带 token，后端零改动，无双重上传
- requestMethod 入参取 `file.raw`（TDesign 传入的是 `{raw: File, ...}` 对象）
- **6 个上传点全覆盖**：Materials:453、Materials:536、Positions:274、ActivityDetail:520、Proposals:525、Proposals:551（补充遗漏点）
- **使用 `theme="file"` + 自定义 `fileListDisplay`**（或 Upload 仅做触发、FileList 做展示），**不使用 `theme="image"`**（所有上传点均为混合文件类型）
- formatResponse 返回 `{ url: getFileUrl(storageKey), ...meta }`（非 `{name, url, status, raw}`）
- 预览策略：图片内联缩略图+点击放大；PDF `window.open` 新标签页内联预览；**Word/Excel 点击即下载（浏览器原生限制，无法在线预览）**——在方案中明确标注此限制
- 非法 key 防御：封装 `isValidStorageKey(key)` 公共函数，正则与后端一致，不满足时显示「文件缺失」灰态
- Proposals 两个上传点（:525、:551）为延迟上传（选完暂存、提交时上传），需配 `autoUpload=false` + 手动触发，或暂不改造保持现有 input
- 配置 `max={20MB}` 前置校验；多文件逐个上传（后端 files:1）
- requestMethod catch 中显式处理 401（清 token 跳登录）

### M4（修订后）
- 先备份：`CREATE TABLE material_files_del_backup_20260908 AS SELECT * FROM material_files WHERE storage_key='test-key-001'`
- 确认：`SELECT id, file_name, material_id FROM material_files WHERE storage_key='test-key-001'`（确认仅 1 条）
- 按 id 精确删除：`DELETE FROM material_files WHERE id='<uuid>'`
- 验证：`SELECT count(*) FROM material_files WHERE storage_key='test-key-001'`（应为 0）
- 备份表保留 7 天后 drop
- **不推荐置空**（幽灵记录体验更差）

### M5（修订后）
- 删除 `backend-new/_diag_invalid_keys.cjs`
- **补充删除 `backend-new/_diag_stage_match.cjs`**
- `_backup_db.cjs` 建议保留（运维工具）或移至 `scripts/`

### 新增（建议本次顺手做）
- **修复 A6**：`web/src/api/files.ts:20-23` 的 `getFileUrl` 去掉 `?token=` 拼接（1 行改动，后端 /files/:key 是公开路由，token 无效且有泄露风险）
- 清理 `Candidates.tsx:39` 的死导入 `getFileUrl, formatFileSize`（可选）

---

## 七、审核总结

| 维度 | 结论 |
|------|------|
| **方案整体准确率** | 约 85%。M1/M2/M4/M5 基本准确，M3 有 3 处必须修正的技术问题 |
| **用户需求理解** | 准确。5 条用户需求均有对应改动点 |
| **M1/M2** | ✅ 可实施（需修行号、标注 organizationName 死代码） |
| **M3** | ⚠️ 需修订后实施（requestMethod 路线、上传点遗漏、theme 不适用 3 项必须修正） |
| **M4** | ✅ 可实施（需按 id 精确删 + 备份流程） |
| **M5** | ⚠️ 需补充（遗漏 _diag_stage_match.cjs） |
| **风险表** | ⚠️ 需补充 8 项遗漏风险（最关键：20MB 限制、files:1、401 处理、回滚方案、A6 token） |
| **与路由审计交叉** | F2 删列决策正确；A6 建议本次顺手修复；F3/分页/A1 无交集 |

**最终结论：⚠️ 需修订。** 按上述「修订后的方案要点」更新 M3（3 项必须修正）、M4（DELETE 方式）、M5（补充脚本）、风险表（补充 8 项）后，方案可通过审核并实施。

---

*本报告为三方独立交叉审计定稿，所有结论均回到具体文件和行号核实。初步方案路径：`docs/Web后台UI改造方案_v1_待审核.md`。*
