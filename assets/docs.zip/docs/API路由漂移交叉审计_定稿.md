# API 路由漂移交叉审计报告（三方独立复核 · 定稿）

> 审计时间：2026-09-08
> 审计方式：3 个子代理独立重新读取源码，逐条验证初步报告结论，再由 Organizer 汇总冲突与共识
> 审计范围：`web/src/api/**` 13 模块 + `web/src/modules/**` 15 页面 + `web/src/layouts/` + `backend-new/src/routes/**` 11 文件 + `server.ts` + `lib.ts` + `client.ts` + `schema.sql`
> 审计原则：只读，未修改任何源码文件，未启动任何服务

---

## 一、初步报告总体准确率

| 审计维度 | 条目数 | 确认 | 纠正 | 补充/新发现 | 准确率 |
|---------|--------|------|------|------------|--------|
| 路由级（R1-R3, B1-B14） | 17 | 16 | 1 | 0 | 94% |
| 字段契约（F1-F10） | 10 | 6 | 3 | 1 | 60% |
| 分页契约 | 1 | 0 | 1 | 0 | 0%（方向对，数量错） |
| 架构规范（A1-A8） | 8 | 6 | 1 | 1 | 75% |
| 数据层（D1-D3） | 3 | 3 | 0 | 0 | 100% |
| **合计** | **39** | **31** | **6** | **2** | **79%** |

**核心判断**：初步报告的大方向全部正确（路由漂移、字段缺失、分页隐患、参数丢弃、架构不统一均属实），但在**严重性评估**和**具体机制描述**上有 6 处偏差，且遗漏了若干同类问题。

---

## 二、关键纠正项（初步报告结论有误）

### 纠正 1：F1 不是"最严重的实时问题"——严重性从高降为中

**初步报告**：「F1 是最严重的字段漂移——`organizationId` 与 `orgId` 不匹配，直接影响账号管理页的归属地显示和过滤。」

**交叉审计结论**：字段不匹配属实，但**当前无实时影响**。

- 后端 `accounts.ts:68` 确实返回 `m.organization_id as "orgId"`，client.ts 不转换已驼峰字段，前端对象上是 `orgId` 而非 `organizationId`。
- 但 `Users.tsx:154` 表格列用的是 `organizationName`（后端 `o.name as "organizationName"` 正常返回），**不读** `account.organizationId`。
- 过滤走服务端 query param（`Users.tsx:61`），后端 `accounts.ts:62-63` 同时接受 `orgId` 和 `organizationId` 两种参数名，**过滤正常工作**。
- `OrgSetup.tsx` 同样不读 `account.organizationId`。

**最终定性**：类型契约违规 + 潜在风险（未来有人消费该字段会踩坑），非当前页面显示故障。严重性 **中**。

---

### 纠正 2：F2 才是最严重的实时故障——严重性从中升为高

**初步报告**：「ElectionFief 的 `termName`/`organizationName`/`unitName` 全为 `undefined`，页面显示空」——标为中。

**交叉审计结论**：属实，且**当前正在造成用户可见的页面故障**，应升为高。

- 后端 `elections.ts:29` 确为 `select * from election_fiefs` 裸查询，无 JOIN。
- `schema.sql:95-108` 确认 election_fiefs 表无 `term_name`/`organization_name`/`unit_name` 列。
- **实时影响**（`Activities.tsx`）：
  - 第 67 行「换届届次」列 `colKey: 'termName'` → **整列空白**
  - 第 68 行「归属村/社区」列 `colKey: 'organizationName'` → **整列空白**
  - 第 115 行届次筛选器 `list.map(a => a.termName)` → **永远空数组，下拉无选项**
  - 第 131 行届次过滤 → **永远不命中**
  - 第 156 行顶部横幅 `{currentFief.organizationName} · {currentFief.name}` → 显示 ` · 活动名`（归属地前缀丢失）

**最终定性**：活动管理主页两列空白 + 筛选器不可用 + 横幅缺信息，**当前实时故障，用户可见**。严重性 **高**。

---

### 纠正 3：F3 candidatePhone 比报告描述更严重——列表和详情都永远空

**初步报告**：「`candidateName` 靠 `|| r.displayName` 兜底」，暗示 candidatePhone 有类似兜底。

**交叉审计结论**：**candidatePhone 在列表和详情中都永远为空**，初步报告的机制描述有误。

- 后端列表查询（`candidates.ts:47-49, 54-56`）只 select 了 `u.display_name`，**没有 select `u.phone`**。所以 `r.phone` 也是 `undefined`，`candidatePhone: r.candidatePhone || r.phone || ''` → 永远空串。
- 后端详情查询（`candidates.ts:66`）选了 `u.phone`，但前端 `getCandidate`（`candidates.ts:70`）**不做字段映射**，直接返回原始响应。原始响应里是 `phone` 而非 `candidatePhone`，所以详情视图中 `candidatePhone` 也为空。
- **实时影响**：
  - `Candidates.tsx:179` 手机号列 `{row.candidatePhone || '—'}` → **永远显示「—」**
  - `Candidates.tsx:161-162` 关键词搜索 `phone.includes(keyword)` → phone 永远空，**手机号搜索永不命中**
  - `Candidates.tsx:409-410` 详情抽屉「联系电话」→ **显示「—」**
  - `Candidates.tsx:476` 审核弹窗 `currentCandidate?.candidateName (currentCandidate?.candidatePhone)` → 显示 ` ()`

**最终定性**：候选人手机号全链路丢失（列表+详情+搜索），**当前实时故障**。candidateName 列表靠 displayName 兜底有值，但详情视图也为空。严重性 **高**。

---

### 纠正 4：分页契约是"3 空 + 1 崩"，不是"4 空 + 1 崩"

**初步报告**：「4 个列表（announcements/candidates/positions/materials）加了分页会瞬间变空，1 个（proposals）会崩溃。」

**交叉审计结论**：**materials 后端不支持分页**，实际是 3 空 + 1 崩。

- 后端 `materials.ts:44-61` 的 zod schema 仅声明 `electionFiefId`，**没有 import parsePagination**，也没有 page/pageSize/limit/offset 字段。即使前端传分页参数，也被 zod strip，后端仍返回全量数组。
- 真正受影响的：
  - `getAnnouncements` → `if (!Array.isArray(res)) return []` → 加了分页变空
  - `getCandidates` → 同上 → 变空
  - `getPositions` → 同上 → 变空
  - `getProposals` → 直接 `return res` → 信封对象 → 组件 `.map()` **TypeError 崩溃**
- modules/ 中确认 0 处分页参数传递，当前未触发。

**最终定性**：契约模糊，一加分页即炸（3 个静默空 + 1 个崩溃）。严重性 **高**（隐患）。

---

### 纠正 5：A7 两个 getOrganizations 不是"同名异义 bug"——严重性从高降为低

**初步报告**：「`api/auth.ts` 和 `api/accounts.ts` 各导出一个 `getOrganizations`，返回类型不同（`OrgItem[]` vs `Organization[]`），同名异义，严重性高。」

**交叉审计结论**：两个函数调用的是**不同后端路由、返回不同数据**，类型差异是**正确的**，并非 bug。

- `auth.ts:54` → `GET /auth/organizations`（**公开路由，无 preHandler**）：SQL `select id,slug,name,org_type,org_type as "orgType",status from organizations where status='active'` → 返回 active 子集，含 orgType，无 createdAt。
- `accounts.ts:47` → `GET /admin/organizations`（`preHandler: roleGuard('platform_admin')`，**仅超管**）：SQL `select id,slug,name,org_type as "orgType",status,created_at from organizations` → 返回全量，含 createdAt，无原始 org_type。
- 调用方也合理：`Users.tsx` 从 auth 导入（登录态下的归属地下拉，只需 active 列表）；`OrgSetup.tsx` 从 accounts 导入（超管开号页，需全量含 createdAt）。

**最终定性**：真正的问题仅是**命名冲突**——同名函数在不同模块中语义不同，维护时易混淆。严重性 **低**（命名规范问题，非功能 bug）。

---

### 纠正 6：B14 /candidate/* 路由是 7 条，不是 6 条

**初步报告**：「全部 `/candidate/*` 路由（6 条）」。

**交叉审计结论**：实际 **7 条**，漏计 `GET /candidate/announcements`（`announcements.ts:93`）。

完整清单：
1. `GET /candidate/elections`（elections.ts:80）
2. `GET /candidate/elections/:id/stages`（elections.ts:83）
3. `GET /candidate/positions`（proposals.ts:255）
4. `POST /candidate/materials`（materials.ts:27）
5. `GET /candidate/materials`（materials.ts:39）
6. `GET /candidate/candidates`（candidates.ts:180）
7. `GET /candidate/announcements`（announcements.ts:93）

---

## 三、确认项（初步报告结论正确）

### 路由级（16/17 确认）

| ID | 结论 | 证据 |
|----|------|------|
| R1 | `GET /admin/announcements/:id` 后端不存在，`getAnnouncement` 死代码 | announcements.ts:89 定义，modules 0 调用 |
| R2 | `GET /admin/materials/:id` 后端不存在，`getMaterial` 死代码 | materials.ts:62 定义，modules 0 调用 |
| R3 | `GET /admin/proposals/:id` 后端不存在，`getProposal` 死代码 | proposals.ts:54 定义，modules 0 调用 |
| B1-B13 | 13 条后端路由 Web 未封装，逐条核实后端注册存在、前端 api/ 无对应封装 | 各路由文件 + server.ts |
| 方法不匹配 | **零问题**。全部 48 个有效前端调用与后端 method+path 一一对应 | 全量比对 |
| modules 直调 | **零问题**。15 个页面全部走 api/ 封装；仅 HeaderIcon.tsx 越层（但路由存在） | 全项目 grep |

### 字段契约（6/10 完全确认）

| ID | 结论 |
|----|------|
| F4 | Announcement.files 列表不返回，确认。**补充：fiefName 也不返回** |
| F5 | createAccount role 前端 string vs 后端 enum，确认。但 UI 已硬编码合法值，实际风险低 |
| F6 | getAnnouncementTemplates 的 orgType/active 参数被后端静默丢弃，确认 |
| F7 | getElectionFiefs 的 termId/status 参数被丢弃，确认 |
| F8 | getCandidates 的 status/currentRound/keyword 参数被丢弃，确认（前端靠客户端内存过滤弥补） |
| F9 | getMaterials 的 status/keyword 参数被丢弃，确认 |
| F10 | getProposals 的 status/keyword 参数被丢弃，确认 |

### 架构规范（6/8 完全确认）

| ID | 结论 |
|----|------|
| A1 | HeaderIcon.tsx:7,66 直接 import request 并调用 `/auth/change-password`，api/auth.ts 未封装。全项目唯一越层点 |
| A2 | announcements.ts:107 和 positions.ts:59 显式设 Content-Type，被 client.ts:43 拦截器 delete，冗余 |
| A3 | archives/positions/webhooks 前端独立模块，后端分别嵌在 elections/proposals/notifications 中，确认。补充 files.ts 对应后端 files.ts（通用）+ biz-files.ts（业务附件） |
| A5 | /dashboard 路由已注册（plugins/index.ts:27）但 menu.ts 无入口，确认 |
| A6 | getFileUrl 拼接 ?token= 但后端 /files/:key 无 auth 中间件，token 被忽略，确认 |
| A8 | candidates.ts:17 `f.org_type === 'community' ? '考察' : '考察'` 死分支，确认 |

### 数据层（3/3 全部确认）

| ID | 结论 |
|----|------|
| D1 | archivesHandler 提案 elId 三级兜底（created_fief_id → 组织最新封地 → organization_id），老数据可能串台，确认 |
| D2 | /candidate/materials 的 org 过滤写在 JOIN ON 中，INNER JOIN 下等效但不规范，确认 |
| D3 | announcements 列表 `select a.*` 返回全列（含编辑态字段），确认 |

---

## 四、新发现问题（初步报告遗漏）

### 新发现 1：9 个死 API 函数（初步报告只列了 3 个）

初步报告 A4 仅列出 `getAnnouncement`/`getMaterial`/`getProposal` 三个详情死函数。交叉审计发现**共 9 个导出但从未使用的 API 函数**：

| # | 函数 | 文件:行 | 后端路由存在？ | 说明 |
|---|------|---------|--------------|------|
| 1 | getAnnouncement | announcements.ts:89 | ❌ 不存在 | A4 已列 |
| 2 | getMaterial | materials.ts:62 | ❌ 不存在 | A4 已列 |
| 3 | getProposal | proposals.ts:54 | ❌ 不存在 | A4 已列 |
| 4 | **getCandidate** | candidates.ts:70 | ✅ 存在（完整聚合查询） | 后端花了 30 行写详情接口但前端无人调用 |
| 5 | **createRole** | roles.ts:21 | ✅ 存在 | 角色管理页无"新建角色"UI |
| 6 | **deleteRole** | roles.ts:29 | ✅ 存在 | 角色管理页无"删除角色"UI |
| 7 | **deleteProposalFile** | proposals.ts:77 | ✅ 存在 | 提案页无删除附件 UI |
| 8 | **deletePositionFile** | positions.ts:66 | ✅ 存在 | 岗位页无删除附件 UI |
| 9 | **deleteAnnouncementFile** | announcements.ts:114 | ✅ 存在 | 活动详情页无删除附件 UI |

严重性：低（死代码不影响运行），但反映前端 UI 缺少删除/详情操作入口，与 B 类（后端有但 Web 未封装）形成镜像——这里是"前端封装了但 UI 未接入"。

### 新发现 2：3 个必填字段后端不返回（初步报告遗漏）

| # | 接口 | 字段 | 文件:行 | 后端实际 | 页面是否消费 |
|---|------|------|---------|---------|------------|
| 1 | Announcement | `fiefName` | announcements.ts:22 | 列表查询 `a.*` 无 fief_name，JOIN election_fiefs 但未 select name | 公告列表归属地列为空 |
| 2 | Proposal | `proposedByName` | proposals.ts:30 | 列表查询无 users JOIN，仅返回 proposedBy（UUID） | 当前页面未消费，无视觉影响 |
| 3 | Position | `fiefName` | positions.ts:10 | 列表查询 `p.*` + files，JOIN election_fiefs 但未 select name | 当前页面未消费，无视觉影响 |

注：Position.fiefName 被字段审计员（N12）和架构审计员（NEW-7）**独立重复发现**，交叉确认。

### 新发现 3：Candidate 详情视图字段映射缺失

`getCandidate`（`candidates.ts:70`）直接 `return res`，不做字段映射。后端详情查询返回 `display_name`→`displayName`、`phone`、`fief_name`→`fiefName`，但前端 Candidate 接口要的是 `candidateName`、`candidatePhone`。导致详情抽屉中姓名和电话都显示「—」。

这与列表视图的映射逻辑（`candidates.ts:46-51`）不一致——列表做了 `candidateName: r.candidateName || r.displayName` 兜底，详情完全没做。

### 新发现 4：archives.ts 冗余 snake_case 回退代码

`archives.ts:29-36` 中每个字段都写了 `r.storage_key || r.storageKey || ''` 形式的双重回退。但后端 archivesHandler 的 SQL 全部使用 camelCase 别名，client.ts 不转换已驼峰字段，所以 `r.storage_key` 等 snake_case 分支**永远不会命中**，是历史遗留的防御性代码。

严重性：极低（纯冗余）。

---

## 五、排查确认无问题的维度

以下维度经交叉审计确认**干净**，初步报告未遗漏问题：

| 排查方向 | 结果 |
|---------|------|
| 前端 API 路径拼写错误 | 全部 40+ 条路径逐一比对，无拼写错误 |
| HTTP 方法不匹配（PUT vs PATCH 等） | 零问题，全部 48 个有效调用 method 一致 |
| 路径参数名不匹配（:fiefId vs :id） | 无运行时不匹配（前端变量名差异不影响 URL） |
| modules/ 页面直调 axios/fetch/request | 零问题（仅 HeaderIcon.tsx 越层，已在 A1 记录） |
| 后端路由注册悬空（server.ts 注册了但无 handler） | 零问题，11 个路由模块全部正常注册 |
| CORS / API 前缀问题 | 零问题，server.ts cors origin:true，无全局前缀 |
| 菜单/路由其他不一致 | 除 dashboard（A5）外全部一致 |
| client.ts snake→camel 转换逻辑本身 | 转换规则正确，无 bug；漂移根源是后端 SQL 驼峰别名绕过转换 |

---

## 六、最终确认的高严重性问题清单

经三方交叉审计，**当前正在影响用户的实时故障**有 2 个，**一触即炸的隐患**有 1 个：

### 🔴 实时故障（用户当前可见）

| 优先级 | 问题 | 影响页面 | 具体表现 |
|--------|------|---------|---------|
| **P0** | **F2：ElectionFief 关联字段缺失** | Activities（活动管理主页） | 「换届届次」「归属村/社区」两列整列空白；届次筛选器永远无选项；顶部横幅缺归属地前缀 |
| **P1** | **F3：Candidate.candidatePhone 全链路丢失** | Candidates（候选人管理） | 列表手机号列永远显示「—」；手机号搜索永不命中；详情抽屉和审核弹窗电话为空 |

### 🟠 高危隐患（当前未触发，一触发即炸）

| 优先级 | 问题 | 触发条件 | 后果 |
|--------|------|---------|------|
| **P0** | **分页契约双形态不兼容** | 任何人在前端给 announcements/candidates/positions 传分页参数 | 3 个列表静默变空（数据消失）；proposals 传分页参数 → TypeError 崩溃 |

### 🟡 中严重性（契约违规 / 潜在风险 / 架构债务）

- F1：Account.organizationId vs orgId 字段不匹配（当前页面未消费，类型契约违规）
- F4：Announcement.files + fiefName 列表不返回（公告列表附件列和归属地列为空）
- A1：HeaderIcon 绕过 API 层直调 request（架构规范，唯一越层点）
- D1：归档提案 elId 三级兜底可能跨活动串台（老数据风险）
- Candidate 详情视图字段映射缺失（详情抽屉姓名/电话为空，与 F3 关联）

---

## 七、核心结论

1. **初步报告大方向正确（79% 准确率）**，所有漂移类别均属实，但在严重性评估上有系统性偏差——**高估了 F1 和 A7，低估了 F2 和 F3**。

2. **真正最严重的实时故障不是 F1，而是 F2**：活动管理主页两列空白 + 筛选器不可用，用户每天打开都能看到。F1（organizationId/orgId）虽然字段不匹配，但当前页面读的是 organizationName（正常返回），过滤走服务端也正常，**没有任何显示空是由 F1 导致的**。

3. **候选人手机号是第二严重的实时故障**：后端列表查询根本没 select `u.phone`，详情查询返回 `phone` 而非 `candidatePhone`，导致列表+详情+搜索全链路丢失。初步报告称"靠 `|| r.phone` 兜底"是错误的——列表查询里 `r.phone` 本身就是 undefined。

4. **分页契约是最大的定时炸弹**：后端双形态返回 + 前端处理不一致，一加分页就 3 个列表变空 + 1 个崩溃。当前 modules 中 0 处分页参数所以未触发，但这是"以前污染严重"的典型遗留——后端开发者知道前端用 Array.isArray 兜底所以默认返回数组，契约模糊且双向不兼容。

5. **路由级维度当前无实时故障**：3 个不存在的详情路由（R1-R3）全是死代码，48 个有效调用 method+path 一一匹配，modules 无直调。路由级是干净的，问题集中在**字段契约层**。

6. **A7 不是 bug**：两个 getOrganizations 调用不同后端路由（公开 active 列表 vs 超管全量），返回数据本就不同，类型差异是正确的。仅命名冲突需要规范。

7. **前端共 9 个死 API 函数**（初步报告只发现 3 个），反映"前端封装了但 UI 未接入"的普遍现象，与后端"有路由但 Web 未封装"形成镜像。

---

*本报告为三方独立交叉审计定稿，所有结论均回到具体文件和行号核实。初步报告路径：`docs/API路由漂移审计_初步报告.md`。*
