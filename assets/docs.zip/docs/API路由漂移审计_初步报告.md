# Web 端 API 路由与后端数据漂移审计报告（初步结论）

> 审计时间：2026-09-08
> 审计范围：`web/src/api/**` 全部 13 个 API 模块 + `backend-new/src/routes/**` 全部 11 个路由文件 + `server.ts` 注册清单 + `schema.sql` 25 张表
> 审计原则：只找问题，不修改代码
> 技术栈：前端 React 18 + TypeScript + Vite + axios；后端 Fastify + TypeScript + Supabase PostgreSQL

---

## 一、路由级漂移（前端调用了后端不存在的路由）

| ID | 前端调用点 | 调用路径 | 后端实际 | 严重性 | 当前是否触发 |
|----|-----------|---------|---------|--------|------------|
| R1 | `web/src/api/announcements.ts:90` | `GET /admin/announcements/:id` | ❌ 不存在。后端只有列表 `GET /admin/announcements`，无单条详情 | 中 | 否（modules 中无人调用 `getAnnouncement`，死代码） |
| R2 | `web/src/api/materials.ts:62` | `GET /admin/materials/:id` | ❌ 不存在。后端只有列表 `GET /admin/materials`，无单条详情 | 中 | 否（modules 中无人调用 `getMaterial`，死代码） |
| R3 | `web/src/api/proposals.ts:54` | `GET /admin/proposals/:id` | ❌ 不存在。后端只有列表 `GET /admin/proposals`，无单条详情 | 中 | 否（modules 中无人调用 `getProposal`，死代码） |

**小结**：3 个详情路由均为死代码，当前不触发 404，但属于"接口契约幻觉"——后续任何人调用都会直接 404。

---

## 二、后端有但 Web 端未封装的路由（能力缺口 / 死路由）

| ID | 后端路由 | 所属文件 | Web 端状态 | 说明 |
|----|---------|---------|-----------|------|
| B1 | `POST /auth/register` | auth.ts | 未封装 | Web 无自助注册页（小程序端使用） |
| B2 | `POST /auth/candidate/login` | auth.ts | 未封装 | Web 是管理端，参选人登录走小程序 |
| B3 | `POST /admin/invitations` | accounts.ts | 未封装 | Web 无邀请码开号 UI |
| B4 | `POST /admin/organizations` | accounts.ts | 未封装 | OrgSetup 页只做列表+批量预设，不新建归属地 |
| B5 | `POST /admin/election-fiefs` | elections.ts | 未封装 | 活动仅通过提案审批自动创建，无手动建活动入口 |
| B6 | `PATCH /admin/election-fiefs/:id/status` | elections.ts | 未封装 | Web 无活动状态切换 UI（draft→active→closed） |
| B7 | `GET /admin/election-fiefs/:id/stage` | elections.ts | 未封装 | 单阶段快照查询，Web 未使用 |
| B8 | `GET /admin/candidates/:id/export` | candidates.ts | 未封装 | 候选人全卷一键导出，Web 未使用 |
| B9 | `POST /admin/candidates/:id/send` | candidates.ts | 未封装 | 候选人送审外送，Web 未使用 |
| B10 | `POST /admin/candidates/:id/review`（单数） | candidates.ts | 未封装 | 后端双注册 `/review` 和 `/reviews` 兼容，Web 只用 `/reviews` |
| B11 | `POST /admin/proposals/sample-file` | proposals.ts | 未封装 | 提案阶段岗位样表上传，Web 改用 `/admin/proposals/:id/file` |
| B12 | `GET /admin/role-permissions` | roles.ts | 未封装 | 权限点字典列表，Web 角色管理页未使用 |
| B13 | `GET /admin/election-fiefs/:id/archives` | elections.ts | 未封装 | 归档别名路由，Web 用 `GET /admin/archives?fiefId=` 代替 |
| B14 | 全部 `/candidate/*` 路由（6 条） | elections/materials/candidates/announcements/proposals | 未封装 | 小程序端参选人视角专用，Web 不涉及 |

**小结**：14 项后端能力 Web 未封装。其中 B5/B6/B8/B9 是有业务价值但 Web 无入口的功能缺口；B1/B2/B14 属于小程序端专属，不算漂移；B10/B11/B13 是后端做的兼容别名，Web 走主路径即可。

---

## 三、字段契约漂移（前端 TypeScript 接口与后端实际返回不一致）

| ID | 位置 | 前端接口字段 | 后端实际返回 | 严重性 | 影响 |
|----|------|------------|------------|--------|------|
| F1 | `api/accounts.ts` Account | `organizationId: string` | SQL 显式别名 `m.organization_id as "orgId"`，返回 `orgId` | **高** | `account.organizationId` 永远为 `undefined`；按归属地过滤等逻辑失效 |
| F2 | `api/elections.ts` ElectionFief | `termName`, `organizationName`, `unitName` | `select * from election_fiefs` 无 JOIN，三个字段均不存在 | 中 | 全为 `undefined`，页面显示空 |
| F3 | `api/candidates.ts` Candidate | `fiefName`, `materialTitle`, `candidateName`, `candidatePhone` | 列表查询返回 `display_name`(→displayName), `phone`；无 `fief_name`/`material_title` | 中 | `fiefName`/`materialTitle` 永远空；`candidateName` 靠 `\|\| r.displayName` 兜底 |
| F4 | `api/announcements.ts` Announcement | `files: MaterialFile[]` | 列表 GET 不 JOIN `announcement_files`，无 `files` 字段 | 中 | 公告列表永远显示无附件，需单独调 `/admin/announcements/:id/files` |
| F5 | `api/accounts.ts` createAccount | `role: string`（任意字符串） | 后端 zod `z.enum(['sub_admin','editor','reviewer'])` | 中 | 若前端传 `platform_admin` 或 `candidate`，后端 400 拒绝 |
| F6 | `api/announcements.ts` getAnnouncementTemplates | params `{orgType?, active?}` | 后端 `GET /admin/announcement-templates` 忽略所有 query，固定 `where active=true` | 低 | 过滤参数静默丢弃 |
| F7 | `api/elections.ts` getElectionFiefs | params `{termId?, status?}` | 后端只解析 `organizationId` | 低 | 过滤参数静默丢弃 |
| F8 | `api/candidates.ts` getCandidates | params `{status?, currentRound?, keyword?}` | 后端只解析 `electionFiefId` + 分页参数 | 低 | 过滤参数静默丢弃 |
| F9 | `api/materials.ts` getMaterials | params `{status?, keyword?}` | 后端只解析 `electionFiefId` | 低 | 过滤参数静默丢弃 |
| F10 | `api/proposals.ts` getProposals | params `{status?, keyword?}` | 后端只解析 `organizationId` + 分页参数 | 低 | 过滤参数静默丢弃 |

**小结**：F1 是最严重的字段漂移——`organizationId` 与 `orgId` 不匹配，直接影响账号管理页的归属地显示和过滤。F2-F4 是关联字段缺失，页面显示空但不崩溃。F6-F10 是查询参数不被后端识别，过滤功能形同虚设。

---

## 四、分页契约系统性漂移（最高危，定时炸弹）

### 后端设计（`lib.ts: parsePagination`）
- 无分页参数 → 返回**原始数组**
- 有任意分页参数（page/pageSize/limit/offset）→ 返回**信封对象** `{ items, total, page, pageSize }`
- 后端注释明确写道："平滑兼容现有 web 列表（web/src/api/*.ts 用 Array.isArray 兜底）"

### 前端实际处理

| API 函数 | 分页时处理方式 | 后果 |
|----------|-------------|------|
| `getAnnouncements` | `if (!Array.isArray(res)) return []` | **静默返回空数组，全部数据消失** |
| `getCandidates` | `if (!Array.isArray(res)) return []` | **静默返回空数组** |
| `getPositions` | `if (!Array.isArray(res)) return []` | **静默返回空数组** |
| `getMaterials` | `if (!Array.isArray(res)) return []` | **静默返回空数组** |
| `getProposals` | 直接 `return res` | 组件拿到 `{items,...}` 对象，调用 `.map()` 时 **TypeError 崩溃** |
| `getAccounts` | 直接 `return res` | 后端无分页，暂时安全 |
| `getElectionFiefs` | 直接 `return res` | 后端无分页，暂时安全 |

### 当前状态
modules 中**未传任何分页参数**（grep 确认 `pageSize|page:|limit:|offset:` 在 modules 中 0 匹配），所以当前未触发。但这是典型的"以前污染严重"遗留——后端开发者知道前端用 Array.isArray 兜底，所以默认返回数组；但一旦任何人在前端加分页参数，4 个列表会瞬间变空，1 个会崩溃。

**严重性：高**。契约模糊且双向不兼容，修复时必须前后端同步改。

---

## 五、架构与规范漂移

| ID | 问题 | 位置 | 严重性 | 说明 |
|----|------|------|--------|------|
| A1 | 绕过 API 层直接调用 request | `layouts/components/Header/HeaderIcon.tsx:66` 直接 `request.post('/auth/change-password')` | 中 | `api/auth.ts` 未封装 changePassword，Header 组件越层直接依赖 axios 实例，破坏 API 层统一管理 |
| A2 | FormData 冗余 Content-Type 头 | `api/announcements.ts:107`、`api/positions.ts:59` 显式设 `'Content-Type': 'multipart/form-data'` | 低 | client.ts 拦截器对 FormData 会 delete Content-Type 让浏览器自动加 boundary，显式设置被拦截器覆盖，属冗余误导代码 |
| A3 | API 模块与后端路由文件不对齐 | Web 有独立 `archives.ts`/`positions.ts`/`webhooks.ts`；后端分别嵌在 `elections.ts`/`proposals.ts`/`notifications.ts` | 低 | 文件组织混乱，增加排查成本，是"污染"的来源之一 |
| A4 | 死 API 函数 | `getAnnouncement`/`getMaterial`/`getProposal` 三个详情函数无任何 module 调用 | 低 | 代码膨胀，且对应后端路由不存在（见 R1-R3） |
| A5 | Dashboard 页面孤儿 | `plugins/index.ts` 注册了 `/dashboard` 路由，但 `configs/menu.ts` 无此菜单项 | 低 | 可通过 URL 直接访问，但菜单不可达 |
| A6 | getFileUrl 拼接 token 到 URL | `api/files.ts:22` 拼接 `?token=`，但后端 `GET /files/:key` 是**公开路由**（无 auth 中间件） | 低 | token 被忽略且暴露在 URL/日志中，无实际鉴权作用 |
| A7 | 重复导出 getOrganizations | `api/auth.ts:54` 和 `api/accounts.ts:47` 各导出一个 `getOrganizations`，返回类型不同（`OrgItem[]` vs `Organization[]`） | 中 | 同名异义，Users.tsx 从 auth 导入，OrgSetup.tsx 从 accounts 导入，易混淆且维护时易漏改 |
| A8 | candidates.ts buildReviewWindows 死分支 | `backend-new/src/routes/candidates.ts:17` `f.org_type === 'community' ? '考察' : '考察'` 两个分支完全相同 | 低 | 原意为社区用"党工委考察"、村用"党委考察"，但写成了同一个值 |

---

## 六、数据层漂移（路由 SQL 与 schema 对照）

| ID | 问题 | 位置 | 严重性 |
|----|------|------|--------|
| D1 | `elections.ts` archivesHandler 中提案 elId 兜底逻辑复杂 | 提案无直接封地外键，用 `created_fief_id` → 组织最新封地 → `organization_id` 三级兜底 | 中 | 老数据可能被错误归到最新封地，归档台账出现跨活动串台 |
| D2 | `materials.ts` GET /candidate/materials 的 org 过滤写在 JOIN ON 中 | `join election_fiefs f on f.id=m.election_fief_id and f.organization_id=$2` | 低 | INNER JOIN 下与 WHERE 等效，但写法不规范，后续改 LEFT JOIN 会出 bug |
| D3 | `announcements.ts` 列表查询 `select a.*` 返回全部 20+ 列 | 包含 `ann_sign`/`ann_remind_to` 等编辑态字段 | 低 | 传输冗余，但 client 自动 snake→camel 后字段可用 |

---

## 七、漂移严重度汇总

| 严重级 | 数量 | 条目 |
|--------|------|------|
| 🔴 高 | 3 | F1（organizationId/orgId 不匹配）、四-分页契约系统性漂移、A7（同名异义 getOrganizations） |
| 🟡 中 | 9 | R1-R3（死详情路由）、F2-F5（字段缺失）、B5/B6/B8/B9（功能缺口）、A1（绕过 API 层）、D1（归档兜底） |
| 🟢 低 | 15 | F6-F10（参数丢弃）、A2-A6/A8（规范问题）、B1-B4/B7/B10-B14（未封装/别名）、D2-D3 |

---

## 八、核心结论

1. **没有前端正在调用的路由会 404**——3 个不存在的详情路由都是死代码，当前不影响运行。
2. **最严重的实时问题是 F1**：账号列表 `organizationId` 字段名不匹配，导致归属地信息丢失。
3. **最大的隐患是分页契约**：后端双形态返回 + 前端 Array.isArray 兜底 = 一加分页就炸。这是"以前污染严重"的典型遗留。
4. **后端能力过剩**：14 条路由 Web 未使用，其中 4 条（手动建活动/状态切换/导出/送审）有业务价值但无 UI 入口。
5. **API 层架构不统一**：A1 越层调用 + A7 同名异义 + A3 文件不对齐，三者叠加造成"路由漂移"的排查困难。

---

*本报告为初步结论，待 sub-agent 交叉审计后定稿。*
