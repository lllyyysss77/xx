# AGENTS.md

## 会话降噪与历史技能触发

- 全程启用降噪原则：遵循 `agent-token-efficiency`（Ponytail/Caveman/Headroom 策略），输入不读废话大文件、输出结论先行、代码杜绝过度封装。
- 组件库能力接入：官方 `tdesign-mcp-server` 已就绪，任何 UI 组件需求优先调用 MCP 查阅文档，严禁手搓原生组件。
- 当本会话对话轮次累计约 20 轮时，优先运行 `E:\zeta-family\skills\xiaxia-historian` 压缩上下文。
- 运行完成后，优先以该次运行的产出物作为后续上下文依据。
- 将更早、重复、已被产出物覆盖的对话内容进行 compact，减少噪声。
- 后续讨论尽量围绕最新产出物展开，避免重复展开旧上下文。

## Notes

- 我们赶紧保存起来记忆哒
