# material_files 脏数据删除备份（2026-09-08）

## 删除前备份（SELECT 原文）
```json
[
  {
    "id": "76076536-6d09-43a4-9fea-7aa3798a6103",
    "material_id": "9a14510e-5db7-4ecd-a239-19b89bbd92a0",
    "storage_key": "test-key-001",
    "file_name": "张三自荐表.jpg",
    "mime_type": "image/jpeg",
    "size_bytes": "102400",
    "created_at": "2026-09-07T23:44:47.363Z"
  }
]
```

## 所属材料
```json
[
  {
    "id": "9a14510e-5db7-4ecd-a239-19b89bbd92a0",
    "title": "主任",
    "status": "submitted"
  }
]
```

## 删除语句（双保险：storage_key + id + file_name）
```sql
DELETE FROM material_files
WHERE storage_key = 'test-key-001'
  AND id = '76076536-6d09-43a4-9fea-7aa3798a6103'
  AND file_name = '张三自荐表.jpg';
```

## 删除后状态
- material_files 表行数：1 → 0（该表仅此 1 行脏数据）
- materials 表 "主任" 材料保留，前端将显示「无附件」空态（M3-第一期覆盖）
- 全表校验：删除后 `SELECT count(*) FROM material_files` = 0

## 回滚
如需恢复，按上方备份 JSON 重新 INSERT 即可。
