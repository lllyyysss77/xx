# 数据库与云服务连接信息

> ⚠️ 敏感信息，请勿提交到公开仓库
> 最后更新：2026-09-07

---

## 1. 本地 PostgreSQL（开发用）

| 项 | 值 |
|---|---|
| 主机 | localhost |
| 端口 | 5432 |
| 数据库 | backend_new |
| 用户名 | postgres |
| 密码 | 123456 |
| 连接串 | `postgresql://postgres:123456@localhost:5432/backend_new` |
| 状态 | ✅ 已建表，已灌真实数据（霞皋村+涧口社区） |

---

## 2. 云开发 CloudBase（腾讯云）

| 项 | 值 |
|---|---|
| 环境 ID | `kaifa-d1gyq07zdce31e09c` |
| 环境别名 | kaifa |
| 地域 | ap-shanghai（上海） |
| 套餐 | 体验版（baas_trial） |
| 数据库类型 | PostgreSQL（共享型） |
| PG 实例名 | pgdb-pjfxmqpl |
| 数据库名 | pgdb-pjfxmqpl |
| 用户名 | cloudbase_postgres_pgdb_pjfxmqpl |
| 公网地址 | 29.42.10.227:50826 |
| 状态 | ✅ 已建表，已灌真实数据 |
| 控制台 | https://tcb.cloud.tencent.com/ |

### 云托管服务

| 服务名 | 类型 | 状态 | 访问地址 |
|---|---|---|---|
| election-backend | 容器型 | 构建中 | https://election-backend-kaifa-d1gyq07zdce31e09c-1251235859.ap-shanghai.run.wxcloudrun.com/ |

### 静态托管

| 项 | 值 |
|---|---|
| 默认域名 | https://kaifa-d1gyq07zdce31e09c-1251235859.tcloudbaseapp.com |
| 状态 | 已开通 |

---

## 3. Supabase

| 项 | 值 |
|---|---|
| 数据库名 | postgres |
| 端口 | 5432 |
| PG 版本 | PostgreSQL 17.6 |
| 架构 | aarch64（ARM） |
| 公网地址（IPv6） | 2406:da18:1f5e:4101:b1b7:40d8:b0f5:5d64 |
| 状态 | ✅ 已建表，已灌真实数据 |
| 密码 | （需从 Supabase 控制台获取，MCP 不暴露） |
| 控制台 | https://supabase.com/dashboard |

> ⚠️ Supabase 连接密码需要登录 Supabase 控制台，在 Project Settings → Database 里查看 Connection String。

---

## 4. 测试账号（所有环境通用）

**统一密码：`Admin@2026`**

| 手机号 | 角色 | 归属组织 | 用途 |
|---|---|---|---|
| 13800000001 | platform_admin（平台超管） | 霞皋村 | 全功能测试 |
| 13800000002 | sub_admin（子管理） | 霞皋村 | 村管理员测试 |
| 13800000003 | editor（公告编辑） | 霞皋村 | 公告编辑测试 |
| 13800000004 | reviewer（材料审核） | 霞皋村 | 材料审核测试 |
| 13800000012 | sub_admin（子管理） | 涧口社区 | 社区管理员测试 |

### 密码哈希（scrypt，用于直接灌库）

```
scrypt:d653b07fd85280e40499e4b3787539f7:c29d21993800cfc750b642bb70aa229f85abc2eef7bf06c6854b1ac528ffc5f6a62ced56201fa7d096fe38699847c947e06c4779fbd0c3d403025b1e0ebf3555
```

---

## 5. 后端本地启动

```bash
cd backend-new
$env:DATABASE_URL="postgresql://postgres:123456@localhost:5432/backend_new"
$env:JWT_SECRET="dev-jwt-secret-key-2026"
$env:PORT="3100"
npx tsx src/server.ts
```

---

## 6. 前端本地启动

```bash
cd web
npm run dev
# 默认端口 3003
```

前端 API 地址在 `web/src/api/client.ts` 中配置，默认指向 `http://localhost:3100`。

---

## 7. 数据状态

| 表 | 数据量 | 说明 |
|---|---|---|
| organizations | 2 | 霞皋村（village）、涧口社区（community） |
| users | 5 | 测试账号 |
| memberships | 5 | 对应 5 个测试账号 |
| roles | 5 | 五角色（platform_admin/sub_admin/editor/reviewer/candidate） |
| election_terms | 1 | 2026年村居换届 |
| election_units | 2 | 对应 2 个组织 |
| 其他业务表 | 0 | 待业务流程产生 |

---

## 8. 已确认的投毒清理项（两轮）

| 文件/位置 | 清理内容 | 状态 | 轮次 |
|---|---|---|---|
| backend-new/src/seed-demo.ts | 假数据种子脚本（演示村/演示社区） | ✅ 已删除 | 第一轮 |
| backend-new/src/seed-candidates.ts | 假候选人种子脚本 | ✅ 已删除 | 第一轮 |
| backend-new/src/import-feishu.py | 飞书脏数据批量注入脚本 | ✅ 已删除 | 第二轮 |
| backend-new/src/import-feishu-runner.mjs | 飞书数据导入运行器 | ✅ 已删除 | 第二轮 |
| backend-new/src/feishu_clean_data.json | 69KB 历史脏数据（含演示账号、选民记录） | ✅ 已删除 | 第二轮 |
| backend-new/src/check-pwd.ts | 含硬编码数据库连接的调试脚本 | ✅ 已删除 | 第二轮 |
| backend-new/src/check-db.ts | 含硬编码数据库连接的调试脚本 | ✅ 已删除 | 第二轮 |
| backend-new/src/check-cr.ts | 含硬编码数据库连接的调试脚本 | ✅ 已删除 | 第二轮 |
| backend-new/src/check-constraint.ts | 含硬编码数据库连接的调试脚本 | ✅ 已删除 | 第二轮 |
| backend-new/src/check-cols.ts | 含硬编码数据库连接的调试脚本 | ✅ 已删除 | 第二轮 |
| backend-new/src/check-biz.ts | 含硬编码数据库连接的调试脚本 | ✅ 已删除 | 第二轮 |
| backend-new/src/reset-pwd.ts | 批量重置密码危险脚本 | ✅ 已删除 | 第二轮 |
| web/src/api/materials.ts | snake_case/camelCase 双读 | ✅ 已清理 | 第一轮 |
| web/src/api/candidates.ts | snake_case/camelCase 双读 | ✅ 已清理 | 第一轮 |
| web/src/api/announcements.ts | snake_case/camelCase 双读 | ✅ 已清理 | 第一轮 |
| web/src/api/positions.ts | snake_case/camelCase 双读 | ✅ 已清理 | 第一轮 |
| web/src/api/archives.ts | snake_case/camelCase 双读 | ✅ 已清理 | 第一轮 |
| web/src/global.d.ts | mock mode 误导声明 | ✅ 已清理 | 第一轮 |
| backend-new/src/routes/elections.ts | `/api/archives` 旧路径兼容路由 | ✅ 已删除 | 第二轮 |
| 数据库 organizations | 124 个脏组织 | ✅ 已清空，保留 2 个真实组织 | 第一轮 |
| 数据库全部业务表 | 脏业务数据 | ✅ 已清空 | 第一轮 |
| 根目录 `_*.cjs` / `_*.py` / `_*.sh` | 8 个历史一次性脚本 | ✅ 已移至 `_removed_legacy/` 归档 | 第二轮 |
