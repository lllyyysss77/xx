# Web 后台 UI 改造方案（v3 · 审核修订版）

> 项目：K:\3\3\纯净交付包（村居换届选举系统）
> 状态：**M1-M5 + M8 已通过交叉审核（修订后），M6-M7 审核中**。代码在线上用，全部改动须经审核后实施。
> 审核基准：2026-09-08，后端 3100 健康检查 `{"ok":true,"service":"cxq-new-backend","db":"up"}`
> 交叉审核报告：`docs/UI改造方案_v1_交叉审核报告.md`（3 子代理独立重读源码，准确率 85%）

---

## 〇、需求清单（用户原话）

1. **「ui后台上每个页面有届次，这个东西不要单独列」** → 列表页的「换届届次」独立列去掉。
2. **「筛选器用关键词，和日期区间就好」** → 列表筛选器只保留关键词 + 日期区间，去掉届次/年份等冗余维度。
3. **「材料预览点击就出现这个，报错」**（`GET /files/test-key-001?token=... 400`）→ 修掉点击预览报错。
4. **「上传的东西好像都不能预览」** → 上传后要能预览。
5. **「腾讯的tdesign有上传组件，官方怎么处理的」+ 官方文档链接** → 上传/预览改用 TDesign `Upload` 官方组件模式。
6. **「活动列表-点击进去的明细页面，列表api调用和数据有问题」** → 活动明细页（ActivityDetail）阶段/公告匹配修复。
7. **「右侧的小编工作台不会随着下拉，会变成左半边下拉很下，右边还在顶部」** → 明细页两栏滚动布局修复。

---

## 一、问题根因（均已实证）

### P1. 材料预览点击 400（`test-key-001`）

- **证据**：数据库直查（`_diag_invalid_keys.cjs`）：`material_files` 表 1 条非法 key `test-key-001`（张三自荐表.jpg），其余 3 张附件表 0 非法。
- **根因**：历史污染数据，不满足后端 `^[a-f0-9]{32}(\.[a-zA-Z0-9]{1,10})?$` 校验，磁盘无此文件。前端点预览 → 后端 400。
- **性质**：① 数据脏；② 前端对非法 key 无防御。

### P2. 上传不能预览

- **证据**：全项目 6 处上传点均手搓 `<input type="file">` + FormData；`FileList.tsx` 仅对 `image/*` 显示预览按钮，PDF/Word 无预览入口。
- **根因**：未用 TDesign Upload 官方组件，预览逻辑不完整。

### P3. 届次列占位无用（用户原话「卵用」）

- **证据**：`ElectionSessionList/index.tsx:33-38` 有 `colKey:'session', title:'换届届次'` 列（4 页面共用）；`Activities.tsx:67` 有 `termName` 列。
- **根因**：后端 `elections.ts:29` 裸 `select *` 无 JOIN，`termName` 恒为 undefined → 届次列整列空白。

### P4. 筛选器冗余

- **证据**：`Activities.tsx:192-236` 筛选条有「届次 / 年份 / 状态」三个 Select；届次下拉恒空（同 P3）。
- **需求**：改为关键词 + 日期区间。

### P5. 活动明细页阶段/公告匹配断裂（用户报「列表api调用和数据有问题」）

- **证据（数据库直查 `_diag_stage_match.cjs`）**：数据库 `stage_templates` 现为 **16 阶段**，前端 `docxRules.ts` 硬编码 **14 阶段**，且 7 处阶段名不一致（如库「初步候选人汇总+镇级初审」vs 前端「初步候选人汇总与镇级初审」、「正式投票选举」vs「法定正式选举日」等），另缺「村民代表和村民小组长选举」「竞选预选」2 阶段。
- **根因**：`ActivityDetail.tsx:137` `docxRuleMap[currentStage.stageName]` 字符串精确匹配 → 绝大多数阶段 undefined → `stageNoticeNos=[]` → 右侧工作台显示「本阶段无需公开发布法定红头公告」、公告列表匹配为空。
- **公告模板侧正常**：`at_code` 为 `第1号~第17号/补充公告/第6-1号`，前端正则可命中。

### P6. 明细页两栏滚动不同步

- **证据**：`ActivityDetail.module.less:58-63` `.mainGrid { align-items:start }`，右栏未吸顶。
- **根因**：左栏 16 阶段时间轴超高，页面滚动后右栏工作台滚出视口。

---

## 二、修改方案（M1-M8）

### M1. ElectionSessionList 去掉届次列（P3）

- 删除 `web/src/modules/common/ElectionSessionList/index.tsx:33-38` 的 session 列（含 `width:140` 和 `cell: ({row}) => <strong>{row.termName || sessionNo(row.name)}</strong>` 兜底渲染）。
- 删除 `index.tsx:6` 的 `sessionNo` import。
- **勿删 `SessionDetailBar.tsx` 中的 `sessionNo` 导出**（第 26 行仍内部自用）。
- 4 个共用页面（Materials/Positions/Candidates/Announcements）同步生效，无需逐页改。
- 剩余列宽自动适配，无需手动调整。
- 纯 UI，无接口变化。

### M2. Activities 去届次列 + 筛选器改造（P3+P4）

- 删除 `web/src/modules/activities/Activities.tsx:67` 的 `termName` 列。
- 筛选条（192-236 行）改造：删届次 Select + 年份 Select，新增关键词 Input + 日期区间 DatePicker，保留状态 Select + 重置按钮 + 计数。
- **关键词仅匹配 `name`**（`organizationName` 后端无值，搜它是死代码；如需搜归属地需后端补 JOIN，超出本次范围）。
- 日期区间按 `dDay` 过滤（dDay 是法定选举日，比 createdAt 更符合选举业务）。
- 联动改动 5 处：① `termFilter/yearFilter` state → `keyword/dateRange` state；② 删 `termOptions/yearOptions` useMemo；③ 重写 `filteredList`；④ 重写 `resetFilters`；⑤ 筛选条 JSX 替换。
- 注明：`Activities.tsx:68` 的 `organizationName`（归属村/社区）列当前恒空白（已知 F2 问题，路由审计定稿确认），本次不处理。
- 纯前端，无接口变化。

### M3. 上传/预览统一改用 TDesign `Upload` 组件（P2，核心变更区）

#### 3.1 上传点全覆盖（6 处，4 个页面）

| # | 文件:行号 | 场景 | 现有上传模式 |
|---|-----------|------|-------------|
| 1 | `Materials.tsx:453` | 组织推荐附件（multiple） | 两步走（uploadMaterialFile 内部先 /files/upload 再关联） |
| 2 | `Materials.tsx:536` | 材料详情补传 | 两步走（同上） |
| 3 | `Positions.tsx:274` | 岗位样表上传 | 直传 multipart（uploadPositionFile → /admin/positions/:id/file） |
| 4 | `ActivityDetail.tsx:520` | 公告附件上传 | 直传 multipart（uploadAnnouncementFile → /admin/announcements/:id/file） |
| 5 | `Proposals.tsx:525` | 提案-逐岗位样表 | 延迟两步走（submit 时 uploadFile 拿 storageKey 嵌入 position） |
| 6 | `Proposals.tsx:551` | 提案-工作方案附件 | 延迟直传（submit 时 uploadProposalFile → /admin/proposals/:id/file） |

#### 3.2 requestMethod 技术路线（审核修正：直接调业务 API，不统一调 /files/upload）

- **requestMethod 内直接调用现有业务 API 函数**（`uploadMaterialFile` / `uploadPositionFile` / `uploadAnnouncementFile` / `uploadProposalFile`），**不统一调 `/files/upload`**。
- 原因：① Materials 的 `uploadMaterialFile` 内部已含 `uploadFile`，再统一调会双重上传；② Positions/Announcements/Proposals 附件的后端端点只接受 multipart 文件本体，无 JSON+storageKey 关联端点；③ 用 `requestMethod` 时 TDesign 完全不走内部 XHR，requestMethod 内可用 axios，拦截器自动带 token。
- requestMethod 入参取 `file.raw`（TDesign 传入的是 `{raw: File, name, size, type, ...}` 对象）。

```typescript
// 示例：Materials
const requestMethod = async (file: { raw: File }) => {
  try {
    const result = await uploadMaterialFile(materialId, file.raw);
    return { status: 'success', response: result };
  } catch (err: any) {
    if (err?.response?.status === 401) { /* 清 token 跳登录 */ }
    return { status: 'fail', error: err.message };
  }
};
```

#### 3.3 展示主题（审核修正：用 theme="file"，不用 theme="image"）

- 所有 6 个上传点均为**混合文件类型**（PDF/Word/Excel/图片），用 `theme="image"` 会导致非图片裂图。
- 使用 `theme="file"` + 自定义 `fileListDisplay`，在自定义渲染中根据 `file.type` 区分：
  - 图片：缩略图 + 点击放大（ImageViewer）
  - PDF：文件图标 + 「预览」按钮（`window.open(url)` 新标签页内联预览）
  - Word/Excel：文件图标 + 「下载」按钮（`window.open(url)` 触发下载，**浏览器原生限制无法在线预览**）
- 或保留现有 `FileList` 组件做展示层，Upload 仅做上传触发（`autoUpload=true`，上传成功后回调更新 FileList 数据）。

#### 3.4 formatResponse（审核修正）

- `formatResponse` 只需返回 `{ url: getFileUrl(storageKey), ...其他元数据 }`。
- `name/raw/status` 由组件内部 `formatToUploadFile` 在文件选中时已设置，不需要 formatResponse 返回。

#### 3.5 预览策略

| 文件类型 | 预览方式 | 可行性 |
|---------|---------|--------|
| 图片 | `<img>` 内联 + ImageViewer 放大 | ✅ |
| PDF | `window.open(url)` 新标签页 | ✅ 后端返回 `Content-Type: application/pdf` |
| Word/Excel | `window.open(url)` | ❌ 只能下载，无法在线预览（浏览器原生限制） |
| txt | `window.open(url)` | ✅ |

#### 3.6 非法 key 防御

- 封装公共函数 `isValidStorageKey(key)`（正则 `^[a-f0-9]{32}(\.[a-zA-Z0-9]{1,10})?$`，与后端 `files.ts:84` 一致）。
- 不满足时不渲染预览/下载入口，显示「文件缺失」灰色态。

#### 3.7 Proposals 延迟上传

- Proposals 两个上传点（:525、:551）为「选择后暂存、点击提交时才上传」，与 TDesign 默认 `autoUpload=true` 冲突。
- 方案：配 `autoUpload=false` + 手动触发（submit 时循环调用 `upload.uploadFiles()`），或暂不改造保持现有 input（评估后决定，优先保证提交链路稳定）。

#### 3.8 上传限制

- 配置 `max={20 * 1024 * 1024}` 前置校验（后端 `server.ts:27` `fileSize: 20MB`）。
- 多文件**逐个上传**（后端 `files:1`，每次请求仅接受 1 个文件，不能批量塞一个 FormData）。

#### 3.9 后端零改动

- `POST /files/upload`、`GET /files/:key`、各业务附件端点契约不变。
- 表述修正：「后端代码零改动（路由/接口契约不变）；M4 为线上数据清理操作，非代码变更」。

### M4. 数据库脏数据处置（P1 根因）

- **先备份**：`CREATE TABLE material_files_del_backup_20260908 AS SELECT * FROM material_files WHERE storage_key='test-key-001'`
- **确认**：`SELECT id, file_name, material_id FROM material_files WHERE storage_key='test-key-001'`（确认仅 1 条）
- **按 id 精确删除**：`DELETE FROM material_files WHERE id='<uuid>'`（因 `storage_key` 无 UNIQUE 约束，不推荐裸 `WHERE storage_key=`）
- **验证**：`SELECT count(*) FROM material_files WHERE storage_key='test-key-001'`（应为 0）
- 备份表保留 7 天后 drop。
- **不推荐置空**（幽灵记录体验更差）。
- 外键方向：`material_files → materials`（ON DELETE CASCADE 指删 materials 时级联删 material_files），反过来删 material_files 行不影响 materials 表。

### M5. 清理临时诊断脚本

- 删除 `backend-new/_diag_invalid_keys.cjs`
- 删除 `backend-new/_diag_stage_match.cjs`
- `_backup_db.cjs` **保留**（运维工具，非临时诊断），或移至 `scripts/` 目录。

### M6. 活动明细页阶段/公告匹配修复（P5，审核中）

- **改 `web/src/utils/docxRules.ts`**：
  - 每个 `DocxStageItem` 增加 `stageKey` 字段（对齐数据库 `stage_key`）。
  - 补齐数据库 16 阶段条目（新增「村民代表和村民小组长选举」→ 公告第5号/第6号/第6-1号、「竞选预选」→ 无公告），修正 7 处阶段名与公告号映射。
  - 村/居两版同步（COMMUNITY_DOCX_STAGES 由 map 派生，注意 stageKey 继承；community 的 key 差异：`resident_reg/resident_list/resident_appeal` vs village 的 `voter_reg/voter_list/voter_appeal`）。
- **改 `web/src/modules/activities/ActivityDetail.tsx`**：
  - `docxRuleMap` 改为按 `stageKey` 建索引：`m[item.stageKey] = item`。
  - `currentStageRule` 用 `docxRuleMap[currentStage.stageKey]`（第 137 行）；左侧时间轴 `docxRuleMap[s.stageKey]`（第 344 行）。
  - 兜底：若某阶段无规则，工作台显示「本阶段无发文动作/线下组织推进」而非空白误提示。
- `docxRules.ts` 仅被 ActivityDetail 一处使用（grep 确认），改造成本低。
- 纯前端，无接口变化。
- **待审核确认**：① stageKey 值域与 SopTimeline/pipelineEngine 一致性；② 第6-1号公告号解析（`parseNoticeNos` 用 `/第(\d+)号/g`，对「第6-1号」提取 "6" 还是 "6-1"？需实测）；③ 19 个公告模板全部可命中。

### M7. 明细页两栏滚动布局修复（P6，审核中）

- **改 `web/src/modules/activities/ActivityDetail.module.less`**：
  - `.workCol { position: sticky; top: 16px; align-self: start; max-height: calc(100vh - 32px); overflow-y: auto; }`（大屏两栏时右栏吸顶独立滚动）。
  - `@media (max-width:1024px)` 单列布局下取消 sticky（`.workCol { position: static; max-height: none; overflow: visible; }`）。
- 纯 CSS，无接口变化。
- **待审核确认**：① sticky 在 grid+align-items:start 下兼容性；② AppLayout 外层滚动容器是否影响 sticky；③ 右栏 max-height 内底部发布按钮可达。

### M8. 修复 A6：getFileUrl 拼 token 泄露（审核建议本次顺手做）

- **改 `web/src/api/files.ts:20-23`**：`getFileUrl` 去掉 `?token=` 拼接，改为仅 `${API_BASE_URL}/files/${encodeURIComponent(storageKey)}`。
- 原因：后端 `/files/:key` 是公开路由（无需 token），token 拼在 URL 中会在 `window.open` 时暴露在地址栏/历史/日志。
- 1 行改动，风险极低。
- 可选：清理 `Candidates.tsx:39` 的死导入 `getFileUrl, formatFileSize`。

---

## 三、风险与控制（审核补充后共 13 项）

| # | 风险 | 等级 | 控制 |
|---|------|------|------|
| 1 | 线上库 DELETE 脏数据 | 中 | 先备份该行；按 id 精确删；仅删 1 行明确污染数据；前端同时加防御 |
| 2 | Upload 组件改造影响既有上传链路 | 中 | 保留原 API 函数签名，仅换 UI 触发层；逐个页面改、逐个验证 |
| 3 | 多页面共改（6 上传点 + 1 展示组件） | 中 | 按 组件层 → 页面层 顺序改；每改一个页面跑一次构建 |
| 4 | 届次列删除影响业务认知 | 低 | 届次信息保留在活动全称列；不删数据不删接口 |
| 5 | 筛选器改坏 | 低 | 纯前端过滤，改完对照原列表逐条核对 |
| 6 | **后端 20MB 文件限制** | 中 | TDesign Upload 配 `max` 前置校验，避免传到后端才被拒 |
| 7 | **后端 files:1 限制** | 中 | 多文件逐个上传（循环逐个 POST），不能批量 |
| 8 | **requestMethod 401 处理** | 中 | catch 中显式判断 401，清 token 跳登录，不静默失败 |
| 9 | **无回滚方案** | 中 | 前端回滚 = git revert + npm run build 重新部署；M4 回滚 = 从备份表 INSERT 恢复 |
| 10 | **测试覆盖不足** | 中 | build 通过 ≠ 功能正常。需 6 上传点手动测试清单（上传→关联→展示→图片预览→PDF预览→非图片下载→非法key灰态→超20MB拦截） |
| 11 | **A6 token 泄露在 URL** | 中 | M8 已修复（去掉 token 拼接） |
| 12 | DELETE 后前端需刷新 | 低 | 无持久化缓存，刷新即可 |
| 13 | 小程序端共用接口 | 低 | 本次仅改 Web 前端、后端契约不变，小程序无感 |

**构建/验证**：`cd web && npm run build`（或 tsc）通过；后端 `npm run dev` 已在线，改动后需重启 web 即可生效（后端无代码改动，除 M4 SQL）。

**回滚方案**：
- 前端：`git revert <commit>` + `npm run build` 重新部署。
- M4 数据：从 `material_files_del_backup_20260908` 备份表 `INSERT INTO material_files SELECT * FROM material_files_del_backup_20260908` 恢复。

---

## 四、明确不做（范围克制）

- 不改后端路由/表结构/接口契约（M4 数据清理除外）。
- 不处理路由漂移审计报告中与本次 UI 无关的项（分页契约、字段名 F1/F3 等）——另行排期。
- 不改小程序端。
- 不引入新的依赖（TDesign 已装）。
- 不重构 `docxRules.ts` 的文案/工作事项内容，仅补 `stageKey`、新增阶段、修正与库对齐的映射。
- Word/Excel 不做在线预览（需第三方服务，超出本次范围），点击即下载。
- `Activities.tsx:68` 的 `organizationName` 列空白（F2）本次不处理（用户只要求删届次）。

---

## 五、审核状态

| 项 | 审核状态 | 结论 |
|----|---------|------|
| M1 删届次列 | ✅ 已通过 | 可实施（修行号 33-38，sessionNo 导入可删但导出勿删） |
| M2 筛选器改造 | ✅ 已通过 | 可实施（关键词仅匹配 name，dDay 选对了，联动 5 处） |
| M3 Upload 改造 | ✅ 修订后通过 | requestMethod 直接调业务 API、6 上传点、theme="file" |
| M4 脏数据清理 | ✅ 已通过 | 按 id 精确删 + 备份流程 |
| M5 清理脚本 | ✅ 已通过 | 补充 _diag_stage_match.cjs，_backup_db.cjs 保留 |
| M6 阶段匹配修复 | ⏳ 审核中 | stageKey 映射、16 阶段补齐、公告号解析 |
| M7 滚动布局修复 | ⏳ 审核中 | sticky 兼容性、外层容器影响 |
| M8 getFileUrl 修复 | ✅ 建议本次做 | 1 行改动，风险极低 |

---

## 六、实施顺序（审核全部通过后）

1. **M8**（getFileUrl 去 token，1 行，风险最低）
2. **M1**（删届次列，纯 UI）
3. **M2**（筛选器改造，纯前端过滤）
4. **M6**（阶段匹配修复，纯前端数据映射）
5. **M7**（滚动布局，纯 CSS）
6. **M3**（Upload 改造，核心风险区，6 上传点逐个改）
7. **M4**（数据库脏数据清理，需二次确认）
8. **M5**（清理临时脚本，最后做）

每步完成后跑 `npm run build`，M3 每改一个上传点手动验证上传→预览链路。
